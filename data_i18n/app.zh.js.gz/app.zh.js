(function () {
  'use strict';

  // На телефоне полоса вкладок в шапке прокручивается по горизонтали; при
  // переходе по Tab фокус не должен уезжать за край экрана.
  document.addEventListener('focusin', function (event) {
    const target = event.target;
    if (target && target.closest && target.closest('.top .tab')) {
      target.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    }
  });

  const HISTORY_KEY = 'samovarHistoryV2';
  const HISTORY_LIMIT = 500;
  const COMMAND_TOKENS = {
    // Успех молчит: подтверждение показываем только там, где страница передала successMessage.
    OK: { ok: true, level: 2, text: '' },
    BUSY: { ok: false, level: 1, text: '设备忙。命令未被接受.' },
    IGNORED: { ok: false, level: 1, text: '命令已忽略.' },
    POWER_OFF: { ok: false, level: 1, text: '加热已关闭。命令未被接受.' },
    PWM_TOO_LOW: { ok: false, level: 1, text: '加热运行时泵PWM低于最小值。命令未被接受.' },
    NOT_RUNNING: { ok: false, level: 1, text: '醪塔程序未运行。命令未被接受.' },
    NO_SETPOINT: { ok: false, level: 1, text: '当前程序行没有蒸汽设定值。命令未被接受.' },
    NO_PUMP: { ok: false, level: 1, text: '需要PWM冷却泵。命令未被接受.' },
    BAD_REQUEST: { ok: false, level: 0, text: '无效命令.' }
  };
  const DECIMAL_PATTERN = /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/;
  const INTEGER_PATTERN = /^[+-]?\d+$/;
  const FLOAT32_MIN_NORMAL = 1.1754943508222875e-38;
  const FLOAT32_MAX = 3.4028234663852886e38;
  const OPERATION_POLL_INTERVAL_MS = 250;
  const OPERATION_TIMEOUT_MS = 45000;
  const MAX_MESSAGE_SEQUENCE = 0xFFFFFFFF;
  const RUNTIME_EVENT_BATCH_LIMIT = 32;
  const RUNTIME_PAIR_PATTERN = /^(?:(?:报警|警告)! )?@P1;s=([0-9A-F]{8});b=([0-9A-F]{8});p=([0-9A-F]{8});e=([BE]);m=([0-7]);r=([0-9A-F]{2});q=([0-9A-F]{2});o=([0-9A-F]{2});t=([0-9A-F]{16})(?:;u=([0-9A-F]{8}))?\|(.+)$/;
  // Служебная метка сообщения (@H1, @L1, @W1…, PIN_SPEC.md §6) нужна журналу сайта, пользователю - текст
  // после «|». У @P1 и @F1 своя строгая проверка: испорченная запись показывается как есть.
  const MESSAGE_TAG_PATTERN = /^@(?!P1;|F1;)[A-Z][0-9]+(?:;[a-z]+=[0-9A-F]+)*\|/;
  const MESSAGE_REBOOT_WARNING = '控制器已重启：消息计数重新开始.';
  const RUNTIME_BUSY_WARNING = '控制器暂时忙，状态将在下次轮询时更新.';
  const TELEMETRY_OPTION_KEYS = [
    'threshold', 'onReady', 'connectionIds', 'storeMessageHistory',
    'dynamicThemeTitle', 'implicitSystemTheme', 'onLastMessageRemoved', 'onConnectionChange'
  ];
  const UI_BOOTSTRAP_KEYS = [
    'mode', 'version', 'powerUnit', 'program', 'description', 'luaButtonList',
    'steamColor', 'pipeColor', 'waterColor', 'tankColor', 'acpColor',
    'steamVisible', 'pipeVisible', 'waterVisible', 'tankVisible', 'pressureVisible',
    'programNumberVisible', 'i2cStepperVisible', 'i2cPumpVisible',
    'hideProcessScheme',
    'beerBrewOrder', 'pwmLow', 'pwmValue', 'nbkDp', 'columnDiameter',
    'columnHeight', 'packDensity', 'heaterResistance', 'mainsVoltage', 'heaterMaxPower',
    'stepperMaxSpeed', 'stepperStepsPerMl', 'i2cSteppers',
    'calibrationRunning', 'processRunning', 'calibrationPump', 'cheesePhSlope', 'cheesePhOffset',
    'cheeseCoolingScheme', 'cheesePhAvailable', 'cheesePhAds1115Address'
  ];
  const UI_BOOTSTRAP_STRING_KEYS = [
    'version', 'powerUnit', 'program', 'description', 'luaButtonList',
    'steamColor', 'pipeColor', 'waterColor', 'tankColor', 'acpColor',
    'cheeseCoolingScheme'
  ];
  const UI_BOOTSTRAP_BOOLEAN_KEYS = [
    'steamVisible', 'pipeVisible', 'waterVisible', 'tankVisible', 'pressureVisible',
    'programNumberVisible', 'i2cStepperVisible', 'i2cPumpVisible', 'calibrationRunning', 'processRunning',
    'cheesePhAvailable', 'hideProcessScheme'
  ];
  const UI_BOOTSTRAP_INTEGER_KEYS = [
    'mode', 'pwmValue', 'packDensity', 'stepperMaxSpeed', 'stepperStepsPerMl',
    'cheesePhAds1115Address'
  ];
  const UI_BOOTSTRAP_NUMBER_KEYS = [
    'pwmLow', 'nbkDp', 'columnDiameter', 'columnHeight', 'heaterResistance',
    'mainsVoltage', 'heaterMaxPower', 'cheesePhSlope', 'cheesePhOffset'
  ];

  let offlineCounter = 0;
  let offlineThreshold = 3;
  let isOffline = false;
  let runtimeBusyCounter = 0;
  let lastValidTelemetryAt = Date.now();
  let messages = [];
  let historyShown = false;
  // Картинки индикатора связи и сирена лежат рядом с app.js. На устройстве это корень,
  // но страницы могут открываться и из подпапки (тесты) - путь берём от самого скрипта.
  const assetBase = (function () {
    const script = document.currentScript;
    try { return script && script.src ? new URL('.', script.src).pathname : '/'; } catch (e) { return '/'; }
  })();
  let soundEnabled = true;
  let soundPlaying = false;
  let audioBlockedNotified = false;
  let alarmActive = false;
  let heaterAlarmLatched = false;
  let connectionAlarm = false;
  let sound = null;
  let requestErrorRevision = 0;
  let programMutationPending = false;
  let messageCursor = 0;
  let messageCursorBootstrapped = false;
  let telemetryRequestInFlight = false;
  let telemetryPageStarted = false;
  let connectionIds = null;
  let storeMessageHistory = true;
  let dynamicThemeTitle = false;
  let implicitSystemTheme = false;
  let onLastMessageRemoved = null;
  let onConnectionChange = null;
  let clockStale = false;
  let pageLockBound = false;
  let bootstrapPending = false;
  let bootstrapStarted = false;
  let deviceScheduleInput = null;
  let deviceScheduleOnSave = null;
  let deviceScheduleMixerStepperAvailable = false;
  let deviceSchedulePumpStepperAvailable = false;
  let luaProgramTextInput = null;
  let luaProgramTimeoutInput = null;
  let luaProgramOnSave = null;

  function byId(id) {
    return document.getElementById(id);
  }

  function requiredI2cPumpElement(id) {
    const element = byId(id);
    if (!element) throw new Error('I2C pump UI contract: missing #' + id);
    return element;
  }

  // Текст состояния детектора примесей, пока он НЕ реагирует (impurity_detector.h,
  // DetectorIdleReason). Пустая строка = детектор активен, показывать статус 0/1/2.
  function detectorIdleText(idle, prgType, waitLeftSec, waitSpan) {
    if (prgType === 'H') return '👁 酒头：观察中';
    switch (idle) {
      case 2: return '👁 酒头：观察中';
      case 3: return '⏳ 程序行开始后暂停';
      case 4: return '⏳ 手动继续后暂停';
      case 5: {
        const left = Number.isFinite(waitLeftSec) && waitLeftSec > 0 ? ', 剩余 ' + Math.ceil(waitLeftSec / 60) + ' min' : '';
        const span = Number.isFinite(waitSpan) && waitSpan > 0 ? ', 波动幅度 ' + waitSpan.toFixed(2) + ' °C' : '';
        return '⏳ 等待蒸汽稳定' + span + left;
      }
      case 6: return '⏳ 正在积累历史数据';
      case 7: return '⏸ 暂停';
      case 8: return '👁 酒尾：观察中';
      case 1: return '— 未启用';
      default: return '';
    }
  }

  function cssVar(name) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  }

  function applySensorColor(id, color) {
    const value = document.getElementById(id).parentElement;
    value.style.color = color;
    value.parentElement.querySelector('i').style.backgroundColor = color;
  }

  function escapeHtml(value) {
    if (value === undefined || value === null) return '';
    return String(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function descriptionByteLength(description) {
    return new TextEncoder().encode(description).length;
  }

  // Правила типов строк программы «Пиво» — единый источник для beer.htm
  // (check_program) и brewxml.htm (validateBeerProgramText); зеркало
  // program_io.h::program_validate_beer_row_semantics.
  function beerRowTypeOk(type, temp, time, noDevice, sensor) {
    if (type === 'M' || type === 'C') return temp > 0 && time === 0;
    if (type === 'F') return temp > 0 && time >= 0;
    if (type === 'P') return temp > 0 && time > 0;
    if (type === 'B') return temp === 0 && time > 0;
    if (type === 'W') return temp === 0 && time === 0;
    if (type === 'L') return temp === 0 && time > 0 && noDevice && sensor === 0;
    if (type === 'A') return temp > 0 && time === 0 && noDevice;
    return false;
  }

  function beerScheduledDeviceValid(device) {
    return device[0] >= 1 && device[0] <= 3 && device[3] > 0 &&
      ((device[0] & 1) || device[1] === 0) &&
      ((device[0] & 2) || device[2] === 0) && device[2] >= 0;
  }

  var BEER_MASH_DEVICE_DEFAULT = '1^-20^0^2^3';
  var BEER_PUMP_CONTINUOUS = '2^0^0^65535^0';
  var BEER_WAIT_DEVICE = '0^0^0^0^0';
  var BEER_PROGRAM_MAX_ROWS = 30;
  var configuredBeerBrewOrderId = 'allinone';

  function beerBrewOrders() {
    return {
      allinone: {
        id: 'allinone',
        label: 'All-in-one / BIAB',
        mashSensor: 0,
        mashDevice: BEER_MASH_DEVICE_DEFAULT,
        hint: '按釜温PID控制（糖化醪），搅拌器与通用程序相同.'
      },
      herms: {
        id: 'herms',
        label: 'HERMS',
        mashSensor: 1,
        mashDevice: BEER_PUMP_CONTINUOUS,
        hint: '按水温PID控制（水箱），泵让糖化醪持续流经盘管循环。釜传感器用于监控糖化醪.'
      },
      rims: {
        id: 'rims',
        label: 'RIMS',
        mashSensor: 2,
        mashDevice: BEER_PUMP_CONTINUOUS,
        hint: '按塔温PID控制（回流），泵持续运行。在真实RIMS上无流量加热很危险.'
      }
    };
  }

  function beerBrewOrder(id) {
    var orders = beerBrewOrders();
    return orders[id] || orders.allinone;
  }

  function setConfiguredBeerBrewOrder(id) {
    configuredBeerBrewOrderId = beerBrewOrder(id).id;
    return configuredBeerBrewOrderId;
  }

  function currentBeerBrewOrderId() {
    var fromBody = document.body && document.body.getAttribute('data-beer-brew-order');
    if (fromBody && beerBrewOrders()[fromBody]) {
      configuredBeerBrewOrderId = fromBody;
    }
    return beerBrewOrder(configuredBeerBrewOrderId).id;
  }

  function beerSensorOptionHtml() {
    return '<option value="0">釜(糖化醪)</option>' +
      '<option value="1">水(水箱 HERMS)</option>' +
      '<option value="2">塔(回流 RIMS)</option>' +
      '<option value="3">蒸汽</option>' +
      '<option value="4">通气管</option>';
  }

  function beerProgramRow(type, temp, time, device, sensor) {
    return type + ';' + temp + ';' + time + ';' + device + ';' + sensor;
  }

  function normalizeMashStepType(raw) {
    if (raw == null) return 'temperature';
    var t = String(raw).trim();
    if (!t || t === '配方中没有') return 'temperature';
    t = t.toLowerCase();
    if (t === 'temperature' || t === 'step' || t === '浸出式') return 'temperature';
    if (t === 'infusion' || t === 'infuse') return 'infusion';
    if (t === 'decoction' || t === '煮出式') return 'decoction';
    return '';
  }

  function effectiveMashKind(stepType) {
    return normalizeMashStepType(stepType);
  }

  function applyBeerBrewOrderToProgramText(text, orderId) {
    var order = beerBrewOrder(orderId);
    var lines = String(text || '').split('\n');
    var out = [];
    for (var i = 0; i < lines.length; i++) {
      var line = lines[i];
      if (line === '') {
        out.push(line);
        continue;
      }
      var f = line.split(';');
      if (f.length !== 5) {
        out.push(line);
        continue;
      }
      if (f[0] === 'M' || f[0] === 'P') {
        f[3] = order.mashDevice;
        f[4] = String(order.mashSensor);
      }
      out.push(f.join(';'));
    }
    return out.join('\n');
  }

  // steps: [{type, temp, time, infuseAmount, infuseTemp, decoctionAmount, name}]
  function buildBeerMashStageLines(steps, orderId) {
    var order = beerBrewOrder(orderId);
    var hints = [];
    var lines = [];
    if (!steps || !steps.length) {
      return { error: '配方中没有糖化步骤', lines: lines, hints: hints };
    }
    for (var i = 0; i < steps.length; i++) {
      var step = steps[i];
      var kind = effectiveMashKind(step.type);
      if (!kind) {
        return {
          error: '未知的糖化步骤TYPE «' + step.type + '» (需要 Infusion, Temperature 或 Decoction)',
          lines: [],
          hints: []
        };
      }
      var n = i + 1;
      var title = step.name ? ('«' + step.name + '»') : ('步骤 ' + n);
      if (kind === 'infusion' && i > 0) {
        var amt = step.infuseAmount ? (step.infuseAmount + ' l') : '计算体积';
        var it = step.infuseTemp ? (step.infuseTemp + ' °C') : '开水';
        hints.push('Infusion ' + title + ': 请加入 ' + amt + ' 水 (' + it + '), 然后点 «下一步».');
        lines.push(beerProgramRow('W', '0', '0', BEER_WAIT_DEVICE, '0'));
      }
      if (kind === 'decoction') {
        var decoct = step.decoctionAmount ? (step.decoctionAmount + ' l') : '糖化醪中较稠的三分之一';
        hints.push('Decoction ' + title + ': 取出 ' + decoct + ', 煮沸后倒回。两行等待，然后保温，加热器不补热，直到暂停.');
        lines.push(beerProgramRow('W', '0', '0', BEER_WAIT_DEVICE, '0'));
        lines.push(beerProgramRow('W', '0', '0', BEER_WAIT_DEVICE, '0'));
      }
      lines.push(beerProgramRow('P', step.temp, step.time, order.mashDevice, String(order.mashSensor)));
    }
    return { error: '', lines: lines, hints: hints };
  }

  // Текст тела ответа для показа человеку: HTML-страницу ошибки веб-сервера
  // (404 и т.п.) не показываем - остаётся только код HTTP.
  function plainBodyText(text) {
    const trimmed = String(text || '').trim();
    return /^<(!doctype|html|head|body)\b/i.test(trimmed) ? '' : trimmed;
  }

  function requestErrorElement() {
    let element = byId('request_error');
    if (element) return element;
    element = document.createElement('div');
    element.id = 'request_error';
    element.className = 'message_0';
    element.setAttribute('role', 'alert');
    element.setAttribute('aria-live', 'assertive');
    element.style.display = 'none';
    element.style.margin = '0.75em auto';
    element.style.maxWidth = '60em';
    element.style.padding = '0.75em 1em';
    const host = document.querySelector('form') || document.body;
    host.insertBefore(element, host.firstChild);
    return element;
  }

  function showRequestError(message, level) {
    requestErrorRevision++;
    const element = requestErrorElement();
    element.className = messageClass(level === undefined ? 0 : level);
    element.textContent = String(message || '请求数据无效.');
    // Крестик: раньше плашка гасла только после следующей удачной операции.
    if (typeof element.appendChild === 'function') {
      const close = document.createElement('button');
      close.type = 'button';
      close.className = 'message-dismiss request-error-close';
      close.setAttribute('aria-label', '隐藏消息');
      close.textContent = '✕';
      close.onclick = clearRequestError;
      element.appendChild(close);
    }
    element.style.display = 'block';
    // Плашка стоит первой в форме: на прокрученной вкладке она за верхним краем экрана.
    if (typeof element.scrollIntoView === 'function') element.scrollIntoView({ block: 'nearest' });
  }

  function clearRequestError() {
    requestErrorRevision++;
    const element = byId('request_error');
    if (!element) return;
    element.textContent = '';
    element.style.display = 'none';
  }

  function currentRequestErrorRevision() {
    return requestErrorRevision;
  }

  function clearRequestErrorIfUnchanged(revision) {
    if (revision !== requestErrorRevision) return false;
    clearRequestError();
    return true;
  }

  function normalizedNumericText(value) {
    return String(value === undefined || value === null ? '' : value).replace(',', '.');
  }

  function fieldLabelFromDom(name) {
    if (!name || typeof document === 'undefined' || !document.querySelector) return null;
    const source = document.querySelector('label[for="' + name + '"]');
    if (!source || typeof source.cloneNode !== 'function') return null;
    const clone = source.cloneNode(true);
    if (typeof clone.querySelectorAll === 'function') {
      const tooltips = clone.querySelectorAll('.tooltiptext');
      for (let i = 0; i < tooltips.length; i++) tooltips[i].remove();
    }
    const text = (clone.textContent || '').trim();
    return text || null;
  }

  function validateNumericInput(inputOrId, options) {
    const input = typeof inputOrId === 'string' ? byId(inputOrId) : inputOrId;
    const spec = options || {};
    const fieldName = input && (input.name || input.id);
    const label = spec.label || fieldLabelFromDom(fieldName) || fieldName || '值';
    if (!input) {
      return { ok: false, error: '未找到字段 «' + label + '».' };
    }

    const normalized = normalizedNumericText(input.value);
    const pattern = spec.integer ? INTEGER_PATTERN : DECIMAL_PATTERN;
    let error = '';
    let value = 0;
    if (normalized === '') {
      error = '字段 «' + label + '» 未填写.';
    } else if (!pattern.test(normalized)) {
      error = '字段 «' + label + '» 必须包含一个数字.';
    } else {
      value = Number(normalized);
      const mantissa = normalized.split(/[eE]/, 1)[0];
      if (!Number.isFinite(value) || (value === 0 && /[1-9]/.test(mantissa))) {
        error = '字段 «' + label + '» 超出允许范围.';
      } else if (!spec.integer && value !== 0 &&
                 (Math.abs(value) < FLOAT32_MIN_NORMAL || Math.abs(value) > FLOAT32_MAX)) {
        error = '字段 «' + label + '» 控制器无法精确表示该数值.';
      } else if (spec.integer && !Number.isSafeInteger(value)) {
        error = '字段 «' + label + '» 必须包含整数.';
      } else if (spec.min !== undefined && value < spec.min) {
        error = '字段 «' + label + '»: 最小值 ' + spec.min + '.';
      } else if (spec.exclusiveMin !== undefined && value <= spec.exclusiveMin) {
        error = '字段 «' + label + '» 必须大于 ' + spec.exclusiveMin + '.';
      } else if (spec.max !== undefined && value > spec.max) {
        error = '字段 «' + label + '»: 最大值 ' + spec.max + '.';
      } else if (spec.accept && !spec.accept(value)) {
        error = spec.acceptMessage || '字段 «' + label + '» 包含无效值.';
      }
    }

    input.setAttribute('aria-invalid', error ? 'true' : 'false');
    if (error) return { ok: false, error: error };
    return { ok: true, number: value, text: normalized, input: input };
  }

  function readNumericInput(inputOrId, options) {
    const result = validateNumericInput(inputOrId, options);
    if (!result.ok) {
      showRequestError(result.error);
      return null;
    }
    result.input.value = result.text;
    return result;
  }

  function validateNumericFields(form, schema) {
    const validated = [];
    for (let i = 0; i < schema.length; i++) {
      const rule = schema[i];
      const input = form.elements[rule.name];
      const result = validateNumericInput(input, rule);
      if (!result.ok) {
        showRequestError(result.error);
        if (input && typeof input.focus === 'function') input.focus();
        return false;
      }
      validated.push(result);
    }
    validated.forEach(function (result) { result.input.value = result.text; });
    clearRequestError();
    return true;
  }

  function operationErrorText(code) {
    const messages = {
      invalid_operation_id: '操作编号无效',
      operation_not_found: '未找到该操作，或其结果已被删除',
      operation_store_full: '操作队列已满',
      operation_store_busy: '操作存储暂时忙',
      invalid_operation_transition: '操作执行顺序被破坏',
      operation_internal: '操作内部错误',
      operation_cancelled: '操作已取消：正在切换模式，或模式已变更',
      process_active: '请先停止流程：流程运行期间此操作不可用',
      profile_persist_failed: '设置无法写入永久存储器',
      mode_switch_failed: '无法完成模式切换；确切原因见日志',
      mode_switch_log_failed: '日志未能完成关闭',
      mode_switch_lua_stop_failed: '未能停止运行 Lua',
      mode_switch_queue_failed: '命令队列未释放',
      mode_switch_actuator_failed: '驱动未确认停止',
      mode_switch_i2c_mixer_failed: 'I2C-搅拌器未确认停止',
      mode_switch_i2c_pump_failed: 'I2C-泵未确认停止',
      mode_switch_local_stepper_failed: '步进电机未停止',
      mode_switch_valve_failed: '阀未关闭',
      mode_switch_mixer_failed: '搅拌器未停止',
      mode_switch_cooling_pump_failed: '冷却泵未停止',
      mode_switch_calibration_failed: '泵校准未完成',
      mode_switch_heater_failed: '加热未确认关闭',
      mode_switch_power_transition_failed: '功率切换未完成',
      mode_switch_nbk_transition_failed: '连续醪塔切换未完成',
      mode_switch_heating_start_failed: '加热启动未取消',
      mode_switch_self_test_failed: '自检未停止',
      mode_switch_owner_failed: '上一模式结束后，程序内部状态未重置',
      mode_switch_lua_reload_failed: '无法重新读取新模式的Lua脚本',
      operation_runtime_busy: '设备正忙于其他操作',
      i2c_config_busy: 'I2C-设备正忙于设置',
      i2c_command_failed: 'I2C-设备未确认命令',
      i2c_device_error: 'I2C-设备报告了错误',
      i2c_refresh_failed: '无法获取I2C设备的当前状态',
      calibration_invalid_result: '收到的校准结果无效',
      operation_stale_reaped: '操作未按时完成，已被停止',
      program_row_locked: '流程运行期间，只能修改、添加和删除当前行之后的行；受影响的行号见消息',
      program_finished: '程序所有行均已执行完毕，流程停止前无法修改程序',
      // Общие признаки отказа запроса (конверт ошибок и текстовые ответы).
      BUSY: '设备忙，请稍后重试',
      BAD_REQUEST: '请求格式错误',
      internal_error: '设备内部错误',
      unavailable: 'I2C-未找到设备，或设备不支持此命令',
      not_available: '所需设备未连接',
      not_allowed: '此处不允许该字段或值',
      stale: '设备上的设置已更改，请刷新页面后重试',
      program: '程序文本有错误',
      // Признаки разбора чисел (numeric_parse_error_code).
      empty: '未设置值',
      format: '值不是数字',
      trailing: '数字后有多余字符',
      range: '值超出允许范围',
      finite: '值不是有限数',
      bounds: '固件中字段范围设置有误',
      allowed: '该值不在允许的列表中',
      argument: '请求参数有误'
    };
    return Object.prototype.hasOwnProperty.call(messages, code) ? messages[code] : code;
  }

  // Прошивка кладёт в message то русскую фразу с подробностями (границы поля, строка
  // программы), то служебный английский текст или сам признак. Русскую фразу показываем
  // как есть, иначе переводим признак и называем поле, к которому он относится.
  function errorEnvelopeText(body) {
    // Старые ответы кладут текст в error, а признак - в code; конверт - message и error.
    const legacy = !body.message && body.code;
    const message = String((legacy ? body.error : body.message) || '');
    const code = String((legacy ? body.code : (body.error || body.err || body.code)) || message);
    if (/[ ]/.test(message)) return message;
    const text = operationErrorText(code);
    if (text === code) return message && message !== code ? message + ' (' + code + ')' : code;
    return text + (body.field ? ' (字段 ' + body.field + ')' : '');
  }

  async function responseErrorText(resp, prefix) {
    let detail = '';
    const contentType = resp.headers.get('Content-Type') || '';
    try {
      if (contentType.indexOf('application/json') !== -1) {
        const body = await resp.json();
        if (body && typeof body === 'object') {
          detail = errorEnvelopeText(body);
        }
      } else {
        detail = operationErrorText(plainBodyText(await resp.text()));
      }
    } catch (err) {
      if (err && err.name === 'AbortError') throw err;
      detail = '';
    }
    return (prefix ? prefix + ': ' : '') + 'HTTP ' + resp.status +
      (detail ? ' — ' + detail : (resp.statusText ? ' — ' + resp.statusText : ''));
  }

  function systemTheme() {
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches
      ? 'dark' : 'light';
  }

  function applyTheme(theme, effectiveTheme) {
    const root = document.documentElement;
    const toggle = byId('themeToggle');
    if (theme === 'dark' || theme === 'light') {
      root.setAttribute('data-theme', theme);
    } else {
      root.removeAttribute('data-theme');
    }
    if (toggle) {
      const dark = (effectiveTheme || theme) === 'dark';
      toggle.textContent = dark ? '☼' : '☾';
      toggle.setAttribute('aria-label', dark ? '切换到浅色主题' : '切换到深色主题');
      toggle.setAttribute('aria-pressed', dark ? 'true' : 'false');
      if (dynamicThemeTitle) {
        toggle.title = dark ? '浅色主题' : '深色主题';
      }
    }
  }

  function initTheme(options) {
    const themeOptions = options || {};
    Object.keys(themeOptions).forEach(function (key) {
      if (key !== 'dynamicThemeTitle' && key !== 'implicitSystemTheme') {
        throw new Error('未知选项 theme: ' + key);
      }
    });
    if (themeOptions.dynamicThemeTitle !== undefined &&
        typeof themeOptions.dynamicThemeTitle !== 'boolean') {
      throw new Error('dynamicThemeTitle 必须为 boolean.');
    }
    if (themeOptions.implicitSystemTheme !== undefined &&
        typeof themeOptions.implicitSystemTheme !== 'boolean') {
      throw new Error('implicitSystemTheme 必须为 boolean.');
    }
    dynamicThemeTitle = themeOptions.dynamicThemeTitle === true;
    implicitSystemTheme = themeOptions.implicitSystemTheme === true;

    let saved;
    if (implicitSystemTheme) {
      try {
        saved = localStorage.getItem('theme');
      } catch (err) {
        saved = null;
      }
    } else {
      saved = localStorage.getItem('theme');
    }
    if (saved === 'dark' || saved === 'light') {
      applyTheme(saved, saved);
      return;
    }
    const effectiveTheme = systemTheme();
    if (implicitSystemTheme) {
      applyTheme(null, effectiveTheme);
    } else {
      applyTheme(effectiveTheme, effectiveTheme);
    }
  }

  function toggleTheme() {
    const attributeTheme = document.documentElement.getAttribute('data-theme');
    const current = implicitSystemTheme && !attributeTheme
      ? systemTheme()
      : (attributeTheme === 'dark' ? 'dark' : 'light');
    const next = current === 'dark' ? 'light' : 'dark';
    if (implicitSystemTheme) {
      try {
        localStorage.setItem('theme', next);
      } catch (err) {
        applyTheme(next, next);
        return;
      }
    } else {
      localStorage.setItem('theme', next);
    }
    applyTheme(next, next);
  }

  function openTab(evt, tabName) {
    const tabcontent = document.getElementsByClassName('tabcontent');
    for (let i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = 'none';
      tabcontent[i].setAttribute('aria-hidden', 'true');
    }
    const tablinks = document.getElementsByClassName('tablinks');
    for (let i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(' active', '');
      if (tablinks[i].hasAttribute('aria-pressed')) {
        tablinks[i].setAttribute('aria-pressed', 'false');
      }
    }
    const tab = byId(tabName);
    if (tab && tab.classList.contains('tabcontent')) {
      tab.style.display = 'block';
      tab.setAttribute('aria-hidden', 'false');
      scheduleProgramHeaderAlign();
    }
    let activeLink = evt && evt.currentTarget;
    if (!activeLink) {
      for (let i = 0; i < tablinks.length; i++) {
        const onclickAttr = tablinks[i].getAttribute && tablinks[i].getAttribute('onclick');
        if (onclickAttr && onclickAttr.indexOf("'" + tabName + "'") !== -1) {
          activeLink = tablinks[i];
          break;
        }
      }
    }
    if (activeLink) {
      activeLink.className += ' active';
      if (activeLink.hasAttribute('aria-pressed')) {
        activeLink.setAttribute('aria-pressed', 'true');
      }
    }
  }

  function openDeviceScheduleModal(input, onSave, mixerStepperAvailable, pumpStepperAvailable) {
    const values = String(input.value || '0^0^0^0^0').split('^');
    if (values.length !== 5) return false;
    deviceScheduleInput = input;
    deviceScheduleOnSave = typeof onSave === 'function' ? onSave : null;
    deviceScheduleMixerStepperAvailable = Boolean(mixerStepperAvailable);
    deviceSchedulePumpStepperAvailable = Boolean(pumpStepperAvailable);
    byId('m_mixer_rpm').parentElement.hidden = !deviceScheduleMixerStepperAvailable;
    byId('m_mixer_relay').hidden = deviceScheduleMixerStepperAvailable;
    byId('m_pump_rate').parentElement.hidden = !deviceSchedulePumpStepperAvailable;
    byId('m_pump_text').textContent = deviceSchedulePumpStepperAvailable &&
      !deviceScheduleMixerStepperAvailable ? '泵，ml/h' :
      '泵：0 = 继电器1，大于0 = I2C步进泵，ml/h';
    byId('m_pump_relay').textContent = deviceScheduleMixerStepperAvailable ?
      '泵：继电器 1 I2CStepper' : '泵：输出 ESP32';
    byId('m_pump_relay').hidden = deviceSchedulePumpStepperAvailable;
    byId('m_type').value = values[0];
    byId('m_mixer_rpm').value = deviceScheduleMixerStepperAvailable ? values[1] : '0';
    byId('m_pump_rate').value = deviceSchedulePumpStepperAvailable ? values[2] : '0';
    byId('m_time').value = values[3];
    byId('m_pause').value = values[4];
    byId('popup').style.display = 'block';
    byId('overlay').classList.add('show');
    return true;
  }

  function closeDeviceScheduleModal() {
    byId('popup').style.display = 'none';
    byId('overlay').classList.remove('show');
    deviceScheduleInput = null;
    deviceScheduleOnSave = null;
  }

  function normalizeDeviceScheduleSeconds(input) {
    let value = String(input.value || '').replace(/[^0-9]/g, '');
    let seconds = parseInt(value, 10);
    if (Number.isNaN(seconds)) seconds = 0;
    if (seconds > 65535) seconds = 65535;
    input.value = String(seconds);
  }

  function saveDeviceScheduleModal() {
    if (!deviceScheduleInput) return false;
    const type = Number(byId('m_type').value);
    if (type === 0) {
      ['m_mixer_rpm', 'm_pump_rate', 'm_time', 'm_pause'].forEach(function(id) {
        byId(id).value = '0';
      });
    }
    const mixer = readNumericInput('m_mixer_rpm', {
      integer: true, min: -32768, max: 32767, label: '搅拌器转速'
    });
    if (!mixer) return false;
    const pump = readNumericInput('m_pump_rate', {
      integer: true, min: 0, max: 65535, label: 'I2C泵速度'
    });
    if (!pump) return false;
    if ((!(type & 1) && Number(mixer.text) !== 0) ||
        (!(type & 2) && Number(pump.text) !== 0)) {
      showRequestError('对于已关闭的设备，请填写 0.');
      return false;
    }
    normalizeDeviceScheduleSeconds(byId('m_time'));
    normalizeDeviceScheduleSeconds(byId('m_pause'));
    const run = readNumericInput('m_time', {
      integer: true, min: 0, max: 65535, label: '设备开启时间'
    });
    if (!run) return false;
    const pause = readNumericInput('m_pause', {
      integer: true, min: 0, max: 65535, label: '设备暂停时间'
    });
    if (!pause) return false;
    deviceScheduleInput.value = byId('m_type').value + '^' + mixer.text + '^' +
      pump.text + '^' + run.text + '^' + pause.text;
    const onSave = deviceScheduleOnSave;
    closeDeviceScheduleModal();
    if (onSave) onSave();
    return true;
  }

  function addLuaProgramArgument(value) {
    const container = byId('lua-program-arguments');
    const row = document.createElement('div');
    row.className = 'modalline lua-program-argument';
    const input = document.createElement('input');
    input.type = 'text';
    input.value = value == null ? '' : String(value);
    input.setAttribute('aria-label', '参数 Lua');
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'program-row-action';
    remove.title = '删除参数';
    remove.setAttribute('aria-label', '删除参数');
    remove.innerHTML = '<img src="minus.png" alt="">';
    remove.addEventListener('click', function () { row.remove(); });
    row.appendChild(input);
    row.appendChild(remove);
    container.appendChild(row);
  }

  async function openLuaProgramModal(textInput, timeoutInput, onSave) {
    let files;
    try {
      const response = await fetch('/edit?list=/');
      if (!response.ok) throw new Error('HTTP ' + response.status);
      files = await response.json();
    } catch (error) {
      notify('无法获取Lua文件列表: ' + error.message, 1);
      return false;
    }
    const luaFiles = files
      .filter(function (item) { return item && item.type === 'file' && /\.lua$/i.test(item.name); })
      .map(function (item) { return String(item.name).replace(/^\//, ''); })
      .filter(function (name) { return name !== 'script.lua' && name.indexOf('btn_') !== 0; });
    if (luaFiles.length === 0) {
      notify('Samovar存储器中没有Lua文件.', 1);
      return false;
    }
    luaProgramTextInput = textInput;
    luaProgramTimeoutInput = timeoutInput;
    luaProgramOnSave = typeof onSave === 'function' ? onSave : null;
    const parts = String(textInput.value || '').split('^');
    const select = byId('lua-program-file');
    select.innerHTML = '';
    luaFiles.forEach(function (name) {
      const option = document.createElement('option');
      option.value = name;
      option.textContent = name;
      select.appendChild(option);
    });
    if (parts[0] && luaFiles.indexOf(parts[0]) >= 0) select.value = parts[0];
    byId('lua-program-timeout').value = String(timeoutInput.value || '1');
    byId('lua-program-arguments').innerHTML = '';
    parts.slice(1).forEach(function (value) { addLuaProgramArgument(value); });
    byId('lua-program-popup').style.display = 'block';
    byId('lua-program-overlay').classList.add('show');
    return true;
  }

  function closeLuaProgramModal() {
    byId('lua-program-popup').style.display = 'none';
    byId('lua-program-overlay').classList.remove('show');
    luaProgramTextInput = null;
    luaProgramTimeoutInput = null;
    luaProgramOnSave = null;
  }

  function saveLuaProgramModal() {
    if (!luaProgramTextInput || !luaProgramTimeoutInput) return false;
    const timeout = readNumericInput('lua-program-timeout', {
      integer: true, min: 1, max: 65535, label: 'Lua阶段超时'
    });
    if (!timeout) return false;
    const values = [];
    const inputs = byId('lua-program-arguments').querySelectorAll('input');
    for (let i = 0; i < inputs.length; i++) {
      const value = inputs[i].value;
      if (value === '') {
        notify('参数为空：请填写 "" 或将其删除.', 1);
        inputs[i].focus();
        return false;
      }
      if (value.indexOf('^') >= 0) {
        notify('字符 ^ 用作参数分隔符.', 1);
        inputs[i].focus();
        return false;
      }
      values.push(value);
    }
    luaProgramTextInput.value = [byId('lua-program-file').value].concat(values).join('^');
    luaProgramTimeoutInput.value = timeout.text;
    const onSave = luaProgramOnSave;
    closeLuaProgramModal();
    if (onSave) onSave();
    return true;
  }

  function setConnectionIcon(fileName) {
    if (connectionIds) {
      const online = byId(connectionIds.online);
      const offline = byId(connectionIds.offline);
      const connected = fileName === 'Green.png';
      online.style = connected ? '' : 'visibility: hidden;position: fixed;';
      offline.style = connected ? 'visibility: hidden;position: fixed;' : '';
      return;
    }
    const indicator = byId('connection_indicator');
    if (!indicator) return;
    indicator.innerHTML = '<img src="' + assetBase + fileName + '" style="margin: 0 !important; width: 20px">';
  }

  function initConnection(options) {
    offlineThreshold = options && options.threshold ? options.threshold : 3;
    connectionIds = options && options.connectionIds ? options.connectionIds : null;
    setConnectionIcon('Green.png');
  }

  function onLockedPageInput(event) {
    if (!document.documentElement.classList.contains('connection-lost')) return;
    event.preventDefault();
    event.stopPropagation();
  }

  function bindPageLock() {
    if (pageLockBound) return;
    pageLockBound = true;
    document.addEventListener('click', onLockedPageInput, true);
    document.addEventListener('pointerdown', onLockedPageInput, true);
    document.addEventListener('keydown', onLockedPageInput, true);
    document.addEventListener('submit', onLockedPageInput, true);
  }

  function assertOnline() {
    if (bootstrapPending) throw new Error('初始数据尚未加载：操作已锁定.');
    if (isOffline) throw new Error('无连接：操作已锁定.');
  }

  // Обрыв связи: вся страница приглушается и блокируется (клики, клавиатура,
  // правки). Иначе оператор жмёт по застывшим кнопкам и полям. Часы помечаются
  // текстом «Нет связи, данные от …», чтобы было видно, насколько цифры старые.
  function applyStaleVisuals(offline) {
    const clock = byId('crnt_tm');
    const root = document.documentElement;
    if (offline) {
      if (clockStale) return;
      clockStale = true;
      if (clock) {
        clock.textContent = '无连接，数据来自 ' + clock.textContent;
      }
      root.classList.add('connection-lost');
      document.body.inert = true;
      const active = document.activeElement;
      if (active && active !== document.body && typeof active.blur === 'function') {
        active.blur();
      }
    } else {
      clockStale = false;
      root.classList.remove('connection-lost');
      document.body.inert = false;
    }
  }

  function setConnectionError(staleTelemetry) {
    if (!staleTelemetry && offlineCounter < offlineThreshold) {
      offlineCounter++;
      return;
    }
    setConnectionIcon('Red_light.gif');
    connectionAlarm = true;
    addMessage('连接中断!', 0);
    setTimeout(function () {
      isOffline = true;
      if (connectionIds) offlineCounter = 0;
      else offlineCounter++;
      applyStaleVisuals(true);
      if (onConnectionChange) onConnectionChange(true);
    }, 100);
  }

  function setConnectionOk() {
    connectionAlarm = false;
    setConnectionIcon('Green.png');
    isOffline = false;
    offlineCounter = 0;
    applyStaleVisuals(false);
    showMessages();
    if (onConnectionChange) onConnectionChange(false);
  }

  function getHistory() {
    try {
      const parsed = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
      return Array.isArray(parsed) ? parsed.slice(-HISTORY_LIMIT) : [];
    } catch (err) {
      console.log('History parse error:', err);
      return [];
    }
  }

  function saveHistory(entry) {
    const saved = getHistory();
    saved.push(entry);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(saved.slice(-HISTORY_LIMIT)));
  }

  function renderHistoryEntry(entry) {
    return '<div align="left" class="' + escapeHtml(entry.cssClass) + '" style="margin-top: 0">' +
      '<span style="text-decoration: underline">' + escapeHtml(entry.time) + '</span> ' +
      escapeHtml(entry.msg) + '</div>';
  }

  // Закрытие истории по Esc и по клику/касанию вне окна: кнопка ☰ на планшете
  // бывает накрыта самим окном или лентой сообщений, и другого выхода не было.
  function onHistoryKeydown(event) {
    if (event.key === 'Escape' || event.key === 'Esc') showHistory();
  }

  function onHistoryPointerdown(event) {
    const box = byId('historyBox');
    const trigger = document.querySelector('.history-trigger');
    if ((box && box.contains(event.target)) || (trigger && trigger.contains(event.target))) return;
    showHistory();
  }

  function showHistory() {
    const box = byId('historyBox');
    const list = byId('historyList');
    const trigger = document.querySelector('.history-trigger');
    if (!box || !list) return;
    if (historyShown) {
      box.style.display = 'none';
      historyShown = false;
      if (trigger) trigger.setAttribute('aria-expanded', 'false');
      document.removeEventListener('keydown', onHistoryKeydown);
      document.removeEventListener('pointerdown', onHistoryPointerdown);
      return;
    }
    list.innerHTML = getHistory().map(renderHistoryEntry).join('');
    box.style.display = 'block';
    box.scrollTop = box.scrollHeight;
    historyShown = true;
    if (trigger) trigger.setAttribute('aria-expanded', 'true');
    document.addEventListener('keydown', onHistoryKeydown);
    document.addEventListener('pointerdown', onHistoryPointerdown);
  }

  function clearHistory() {
    localStorage.setItem(HISTORY_KEY, JSON.stringify([]));
    historyShown = false;
    showHistory();
  }

  function messageClass(level) {
    if (level === 1) return 'message_1';
    if (level === 2) return 'message_2';
    return 'message_0';
  }

  function renderMessage(entry, index) {
    const content = escapeHtml(entry.time) + '  ' + escapeHtml(entry.msg);
    // Раньше вся строка была кнопкой-самоудалением - случайный тычок в аварийное
    // сообщение (например, при захлёбе, который живёт только в тексте, без latch)
    // гасил его вместе с сиреной незаметно для пользователя. Удаляет только отдельный
    // крестик; у аварийных сообщений removeMessage() дополнительно спрашивает подтверждение.
    const last = index === messages.length - 1;
    const handler = last ? 'SamovarApp.removeLastMessage()' : 'SamovarApp.removeMessage(' + index + ')';
    return '<div align="left" class="' + escapeHtml(entry.cssClass) +
      '" style="display: flex; justify-content: space-between; align-items: center; gap: 0.5em;">' +
      '<span>' + content + '</span>' +
      '<button type="button" class="message-dismiss" aria-label="隐藏消息" ' +
      'onclick="' + handler + '">✕</button></div>';
  }

  function pushMessage(msg, level) {
    const time = new Date().toLocaleTimeString('zh-CN');
    const cssClass = messageClass(level);
    const entry = { time: time, msg: String(msg), cssClass: cssClass };
    if (storeMessageHistory) saveHistory(entry);
    messages.push(entry);
    showMessages();
  }

  function addMessage(msg, level) {
    if (isOffline) return;
    pushMessage(msg, level);
  }

  function notify(msg, level) {
    pushMessage(msg, level === undefined ? 1 : level);
  }

  // message_0 - аварийный уровень (level 0). Для аппаратной защёлки нагрева
  // и обрыва связи сирена живёт отдельно от тоста: спрашиваем подтверждение,
  // чтобы случайный тычок не прятал аварию молча.
  function confirmMessageRemoval(entry) {
    return entry.cssClass !== 'message_0' ||
      confirm('隐藏紧急消息 «' + entry.msg + '»?');
  }

  function removeMessage(index) {
    if (index < 0 || index >= messages.length) return;
    if (!confirmMessageRemoval(messages[index])) return;
    messages.splice(index, 1);
    if (onLastMessageRemoved) onLastMessageRemoved(messages.length);
    showMessages();
  }

  function removeLastMessage() {
    if (messages.length === 0) return;
    if (!confirmMessageRemoval(messages[messages.length - 1])) return;
    messages.pop();
    if (onLastMessageRemoved) onLastMessageRemoved(messages.length);
    showMessages();
  }

  function clearMessages() {
    messages = [];
    showMessages();
  }

  function updateHeaterAlarmLatched(latched, reason) {
    heaterAlarmLatched = latched;
    if (latched) {
      // Живое сообщение об аварии уже на экране - не дублируем. Иначе (страница
      // открыта позже, в т.ч. уже в другом режиме) поясняем, что это запомненная
      // авария, а не новая: причина может называть прежний режим.
      const present = messages.some(function (entry) { return entry.msg.indexOf(reason) !== -1; });
      if (!present) {
        pushMessage('加热已锁定，直到控制器重启。原因: ' + reason, 0);
      }
    }
    showMessages();
  }

  function showMessages() {
    const box = byId('messagesBox');
    const list = byId('messages');
    // Сирена: аппаратная защёлка нагрева ИЛИ подтверждённый обрыв связи.
    // Обычный message_0 (датчик ТСА, захлёб в ленте и т.п.) в тосте есть,
    // но не крутит alarm.mp3 - иначе открытие страницы с хвостом ошибки орёт сразу.
    alarmActive = heaterAlarmLatched || connectionAlarm;
    if (box && list) {
      if (messages.length === 0) {
        box.style.display = 'none';
      } else {
        list.innerHTML = messages.map(renderMessage).join('');
        box.style.display = 'block';
        box.scrollTop = box.scrollHeight;
      }
    }
    if (soundEnabled && alarmActive) {
      playSound(true);
    } else {
      playSound(false);
    }
  }

  function ensureSound() {
    if (sound) return sound;
    sound = new Audio(assetBase + 'alarm.mp3');
    sound.loop = true;
    sound.preload = 'auto';
    sound.autoplay = false;
    return sound;
  }

  function notifyAudioBlocked() {
    if (audioBlockedNotified) return;
    audioBlockedNotified = true;
    addMessage('浏览器屏蔽了报警声。请点击页面以允许播放声音.', 1);
  }

  function playSound(play) {
    const alarmSound = ensureSound();
    if (!soundPlaying && play) {
      const result = alarmSound.play();
      soundPlaying = true;
      if (result && typeof result.catch === 'function') {
        result.catch(function () {
          soundPlaying = false;
          notifyAudioBlocked();
        });
      }
    } else if (soundPlaying && !play) {
      alarmSound.pause();
      soundPlaying = false;
    }
  }

  function unlockAudio() {
    const alarmSound = ensureSound();
    alarmSound.play()
      .then(function () {
        alarmSound.pause();
        alarmSound.currentTime = 0;
        soundPlaying = false;
        audioBlockedNotified = false;
        if (soundEnabled && alarmActive) playSound(true);
      })
      .catch(function () {});
  }

  function setSoundEnabled(enabled) {
    soundEnabled = !!enabled;
    if (!soundEnabled) playSound(false);
  }

  function renderI2cPumpStatus(data) {
    const panel = requiredI2cPumpElement('i2c_pump_status');
    const status = requiredI2cPumpElement('i2c_status');
    const remaining = requiredI2cPumpElement('i2c_remaining');
    const speed = requiredI2cPumpElement('i2c_speed_cur');
    const present = data.i2c_pump_present === 1;

    panel.hidden = !present;
    status.textContent = present
      ? (data.i2c_pump_running === 1 ? '运行中' : '已停止')
      : '未连接';
    remaining.textContent = present ? data.i2c_pump_remaining_ml : '0';
    speed.textContent = present ? data.i2c_pump_speed : '0';
  }

  // Подсказки как в 6.27: CSS :hover/:focus-within на .tooltip .tooltiptext.
  // Страницы всё ещё вызывают enhanceTooltips() после перерисовки программы.
  function enhanceTooltip(container) {}
  function enhanceTooltips(root) {}

  // ==================== Общая часть renderTelemetry ====================
  // version/crnt_tm/stm, блок мощности, служебные показания (heap/rssi/...), звук,
  // Lstatus и подпись насоса воды - одинаковы на index/beer/bk/nbk/distiller.htm.
  // Формат current_power_volt/target_power_volt - единственное, что реально
  // отличается (distiller.htm и index.htm показывают десятые), поэтому это параметр,
  // а не отдельная копия функции. Рендер I2C-насоса и кнопку нагрева страницы
  // вызывают сами, отдельно от этой функции: smoke_i2c_pump_ui_contract.py требует,
  // чтобы SamovarApp.renderI2cPumpStatus(myObj) и запись
  // document.getElementById('power').value были видны прямо в коде страницы.
  function renderTelemetryCommon(myObj, options) {
    var opts = options || {};
    byId('version').textContent = myObj.version;
    byId('crnt_tm').textContent = myObj.crnt_tm;
    byId('stm').textContent = myObj.stm;

    var voltFixed = opts.powerVoltFixed;
    byId('current_power_volt').innerHTML = voltFixed === undefined
      ? myObj.current_power_volt
      : myObj.current_power_volt.toFixed(voltFixed);
    byId('target_power_volt').innerHTML = voltFixed === undefined
      ? myObj.target_power_volt
      : myObj.target_power_volt.toFixed(voltFixed);
    byId('current_power_mode').innerHTML = myObj.current_power_mode;
    byId('current_power_p').innerHTML = myObj.current_power_p;

    byId('bme_temp').innerHTML = myObj.bme_temp;
    byId('heap').innerHTML = myObj.heap;
    byId('rssi').innerHTML = myObj.rssi;
    byId('fr_bt').innerHTML = myObj.fr_bt;
    setSoundEnabled(!!myObj.UseBBuzzer);

    if (myObj.Lstatus) {
      if (myObj.Lstatus != "") {
        byId('Lstatus').textContent = myObj.Lstatus;
      }
    }

    if (myObj.wp_spd !== undefined) {
      byId('add_param').textContent = "; 水泵PWM: " + myObj.wp_spd;
    }
    renderUiDetails(myObj);
  }

  const UI_PHASE_NAMES = ['空闲', '程序行', '加热', '稳定', '保温', '冷却', '等待操作员', '驱动确认', '安全等待', '已知的Lua操作', '结束中', '错误', '未知的Lua阶段', '取酒头'];
  const UI_END_NAMES = ['', '传感器阈值', '体积', '酒精度', '比例', '时间', '驱动结果', '操作员操作', '程序结束', 'Lua操作结果', '温度平台'];
  const UI_END_SOURCE_NAMES = ['', '按蒸汽', '按塔', '按水', '按釜', '按通气管', '按 pH', '按定时器', '按体积', '按驱动'];
  const UI_END_OPERATOR_NAMES = ['', '不低于', '不高于', '时间到时', '确认后', '手动'];
  const UI_WAIT_NAMES = ['', '精馏手动暂停', '酿造手动暂停', '等待蒸汽温度', '等待塔温度', '检测器暂停', '程序暂停', '蒸馏加热', '酒精度不可靠', '等待醪塔沸腾', '醪塔功率确认', '连续醪塔切换', '连续醪塔安全等待', '等待麦芽', '冷却跳过确认', '啤酒保温冻结', '酿造等待操作员', '低温慢煮保温超出范围', '奶酪保温冻结', '奶酪等待操作员', '奶酪加料', '温度确认/pH', '驱动确认', '已知的Lua操作'];
  const UI_CONTINUATION_NAMES = ['继续方式未知', '自动', '操作员操作后', '驱动确认后', '换行时', '流程结束时'];
  const UI_UNIT_NAMES = ['', '°C', 'ml', 'l/h', '%', 'pH', 's', 'min', '开/关', 'V', 'W', 'PWM'];
  const UI_SOURCE_NAMES = ['来源未知', '按程序', '手动', '水自动控制', '保护', '操作', '自动速度', '检测器'];
  const UI_EQUIPMENT_NAMES = ['', '加热', '采出', '水', '搅拌器', 'I2C-泵', '连续醪塔进料'];

  function uiWaitReasonName(code) {
    return UI_WAIT_NAMES[code];
  }

  function hasUiInteger(value, min, max) {
    return Number.isInteger(value) && value >= min && value <= max;
  }

  function hasUiValue(value) {
    return (typeof value === 'number' && Number.isFinite(value)) || typeof value === 'boolean';
  }

  function validateUiCondition(condition) {
    return condition && typeof condition === 'object' && hasUiInteger(condition.e, 1, 10) &&
      (condition.es === undefined || hasUiInteger(condition.es, 0, 9)) &&
      (condition.eo === undefined || hasUiInteger(condition.eo, 0, 5)) &&
      (condition.ev === undefined || Number.isFinite(condition.ev)) &&
      (condition.eu === undefined || hasUiInteger(condition.eu, 0, 8)) &&
      ((condition.ev === undefined) === (condition.eu === undefined)) &&
      (condition.et === undefined || hasUiInteger(condition.et, 0, 0xFFFFFFFF));
  }

  function validateUi(ui) {
    if (!ui || typeof ui !== 'object' || !hasUiInteger(ui.m, 0, 7) || !hasUiInteger(ui.p, 0, 13) ||
        (ui.r !== undefined && !hasUiInteger(ui.r, 1, 255)) ||
        (ui.n !== undefined && !hasUiInteger(ui.n, 1, 255)) ||
        (ui.ls !== undefined && (ui.m !== 6 || typeof ui.ls !== 'string'))) return false;
    const hasEnd = ui.e !== undefined || ui.es !== undefined || ui.eo !== undefined ||
      ui.ev !== undefined || ui.eu !== undefined || ui.et !== undefined;
    if (hasEnd && !validateUiCondition(ui)) return false;
    if (ui.g !== undefined && (!Array.isArray(ui.g) || ui.g.length > 2 || !ui.g.every(validateUiCondition))) return false;
    if (ui.w !== undefined && (!Array.isArray(ui.w) || ui.w.length > 2 || !ui.w.every(function(wait) {
      return wait && typeof wait === 'object' && hasUiInteger(wait.q, 1, 23) && hasUiInteger(wait.co, 0, 5);
    }))) return false;
    if (ui.c !== undefined && (!Array.isArray(ui.c) || ui.c.length > 4 || !ui.c.every(function(control) {
      return control && typeof control === 'object' && hasUiInteger(control.k, 1, 6) &&
        hasUiInteger(control.u, 0, 11) && hasUiInteger(control.s, 0, 7) &&
        (control.r === undefined || hasUiValue(control.r)) && (control.a === undefined || hasUiValue(control.a));
    }))) return false;
    return true;
  }

  function formatUiCondition(condition) {
    const unit = UI_UNIT_NAMES[condition.eu] || '';
    const operator = UI_END_OPERATOR_NAMES[condition.eo] || '';
    const source = UI_END_SOURCE_NAMES[condition.es] || '';
    const target = condition.ev === undefined ? '' : ' ' + condition.ev + (unit ? ' ' + unit : '');
    return UI_END_NAMES[condition.e] + ':' + (operator ? ' ' + operator : '') + target + (source ? ' ' + source : '') +
      (condition.et === undefined ? '' : '; 剩余 ' + condition.et + ' s');
  }

  function renderUiControls(controls) {
    let block = byId('ui_control_details');
    if (!block) {
      const host = document.querySelector('#regulator, .sec-actions');
      if (!host) return;
      block = document.createElement('div');
      block.id = 'ui_control_details';
      block.className = 'meta';
      host.appendChild(block);
    }
    if (!controls || !controls.length) {
      block.style.display = 'none';
      return;
    }
    block.textContent = controls.map(function(control) {
      function valueText(value) {
        if (value === undefined) return '—';
        if (control.u === 8 && (value === true || value === 1)) return '开';
        if (control.u === 8 && (value === false || value === 0)) return '关';
        return String(value) + (UI_UNIT_NAMES[control.u] ? ' ' + UI_UNIT_NAMES[control.u] : '');
      }
      return UI_EQUIPMENT_NAMES[control.k] + ': 已设定 ' + valueText(control.r) +
        ', 已应用 ' + valueText(control.a) + ' (' + UI_SOURCE_NAMES[control.s] + ')';
    }).join('; ');
    block.style.display = '';
  }

  function renderUiDetails(data) {
    let block = byId('ui_details');
    if (!block) {
      const stage = document.querySelector('.stage');
      if (!stage) return;
      block = document.createElement('div');
      block.id = 'ui_details';
      block.className = 'meta';
      stage.appendChild(block);
    }
    const ui = data && data.ui;
    if (!validateUi(ui)) {
      block.textContent = '无法显示详细说明：阶段数据缺失或无效.';
      block.style.display = '';
      renderUiControls(null);
      return;
    }
    const lines = ['阶段: ' + UI_PHASE_NAMES[ui.p]];
    if (Number.isInteger(ui.r)) lines.push('行: ' + ui.r);
    if (ui.e !== undefined) lines.push('结束中: ' + formatUiCondition(ui));
    if (ui.g && ui.g.length) lines.push('流程: ' + ui.g.map(formatUiCondition).join('; '));
    if (Array.isArray(ui.w) && ui.w.length) {
      lines.push('等待: ' + ui.w.map(function (wait) {
        return uiWaitReasonName(wait.q) + '; ' + UI_CONTINUATION_NAMES[wait.co];
      }).join('; '));
    }
    if (Number.isInteger(ui.n)) lines.push('下一步：行 ' + ui.n);
    if (ui.m === 6 && typeof ui.ls === 'string') lines.push('Lua: ' + ui.ls);
    block.textContent = lines.join(' · ');
    block.style.display = '';
    renderUiControls(ui.c);
  }

  async function fetchJson(url, options) {
    const ctrl = new AbortController();
    const timeout = options && options.timeout ? options.timeout : 4000;
    const timer = setTimeout(function () { ctrl.abort(); }, timeout);
    try {
      const resp = await fetch(url, { signal: ctrl.signal });
      clearTimeout(timer);
      if (!resp.ok) {
        setConnectionError();
        return null;
      }
      const data = await resp.json();
      setConnectionOk();
      return data;
    } catch (err) {
      clearTimeout(timer);
      setConnectionError();
      return null;
    }
  }

  function validateRuntimeEventItem(data) {
    const hasMessage = Object.prototype.hasOwnProperty.call(data, 'Msg');
    const hasLog = Object.prototype.hasOwnProperty.call(data, 'LogMsg');
    const hasLevel = Object.prototype.hasOwnProperty.call(data, 'msglvl');
    if (!Number.isInteger(data.messageSequence) ||
        data.messageSequence < 1 || data.messageSequence > MAX_MESSAGE_SEQUENCE ||
        hasMessage === hasLog) {
      throw new Error('运行时消息契约无效.');
    }
    if (hasMessage) {
      if (!hasLevel || typeof data.Msg !== 'string' || data.Msg === '' ||
          !Number.isInteger(data.msglvl) || data.msglvl < 0 || data.msglvl > 255) {
        throw new Error('运行时消息契约无效.');
      }
      return {
        kind: 'message',
        level: data.msglvl,
        sequence: data.messageSequence,
        text: data.Msg
      };
    }
    if (hasLevel || typeof data.LogMsg !== 'string' || data.LogMsg === '') {
      throw new Error('运行时消息契约无效.');
    }
    return {
      kind: 'log',
      sequence: data.messageSequence,
      text: data.LogMsg
    };
  }

  function validateRuntimeEvents(data) {
    const hasSequence = Object.prototype.hasOwnProperty.call(data, 'messageSequence');
    const hasMessage = Object.prototype.hasOwnProperty.call(data, 'Msg');
    const hasLog = Object.prototype.hasOwnProperty.call(data, 'LogMsg');
    const hasLevel = Object.prototype.hasOwnProperty.call(data, 'msglvl');
    const hasEvents = Object.prototype.hasOwnProperty.call(data, 'events');
    if (hasSequence || hasMessage || hasLog || hasLevel) {
      throw new Error('运行时消息契约无效.');
    }
    if (!hasEvents) return [];
    if (!Array.isArray(data.events) || data.events.length > RUNTIME_EVENT_BATCH_LIMIT) {
      throw new Error('运行时消息契约无效.');
    }
    const events = [];
    for (let index = 0; index < data.events.length; index++) {
      const item = data.events[index];
      if (!item || typeof item !== 'object') {
        throw new Error('运行时消息契约无效.');
      }
      events.push(validateRuntimeEventItem(item));
    }
    return events;
  }

  function parseRuntimePair(text) {
    const match = RUNTIME_PAIR_PATTERN.exec(text);
    if (!match) return null;
    const isBegin = match[4] === 'B';
    if ((isBegin && match[8] !== 'FF') ||
        (!isBegin && !/^(?:00|01|02|03|04)$/.test(match[8])) ||
        match[1] === '00000000' || match[3] === '00000000' ||
        (match[6] !== 'FF' && match[6] === '00') ||
        match[7] === '00' || Number.parseInt(match[7], 16) > 23) {
      return null;
    }
    return {
      sessionId: match[1],
      bootId: match[2],
      pairId: match[3],
      event: isBegin ? 'begin' : 'end',
      mode: match[5],
      row: match[6],
      reason: match[7],
      outcome: match[8],
      monotonicMs: match[9],
      utc: match[10] || null,
      text: match[11]
    };
  }

  function validateHeaterTelemetry(data) {
    if ((data.heaterAlarmLatched !== 0 && data.heaterAlarmLatched !== 1) ||
        typeof data.heaterAlarmReason !== 'string' ||
        !Number.isInteger(data.latestMessageSequence) ||
        data.latestMessageSequence < 0 || data.latestMessageSequence > MAX_MESSAGE_SEQUENCE) {
      throw new Error('契约无效 heaterAlarmLatched/heaterAlarmReason/latestMessageSequence.');
    }
    const latched = data.heaterAlarmLatched === 1;
    // heaterAlarmReason живёт вместе с защёлкой (до перезагрузки ESP).
    // Кольцо событий может вытеснить исходный SendMsg; пустая причина при
    // latch=1 — нарушение контракта, не «нет текста».
    if (latched === (data.heaterAlarmReason === '')) {
      throw new Error('契约无效 heaterAlarmLatched/heaterAlarmReason/latestMessageSequence.');
    }
    return {
      heaterAlarmLatched: latched,
      reason: data.heaterAlarmReason,
      latestSequence: data.latestMessageSequence
    };
  }

  function resolvePollSinks(sinks) {
    if (sinks === undefined) {
      return {
        message: addMessage,
        log: function (text, data) { console.log(data.crnt_tm + '; ' + text); },
        connection: function (hasError, staleTelemetry) {
          if (hasError) setConnectionError(staleTelemetry);
          else setConnectionOk();
        }
      };
    }
    if (!sinks || typeof sinks.message !== 'function' ||
        typeof sinks.log !== 'function' || typeof sinks.connection !== 'function') {
      throw new Error('处理程序无效 telemetry poll.');
    }
    return sinks;
  }

  function nextMessageSequence(sequence) {
    return sequence === MAX_MESSAGE_SEQUENCE ? 1 : sequence + 1;
  }

  async function pollAjax(renderFn, sinks) {
    if (typeof renderFn !== 'function') {
      throw new Error('未设置处理程序 telemetry response.');
    }
    const activeSinks = resolvePollSinks(sinks);
    if (telemetryRequestInFlight) return false;
    telemetryRequestInFlight = true;
    const ctrl = new AbortController();
    const timer = setTimeout(function () { ctrl.abort(); }, 4000);
    try {
      let data;
      try {
        const resp = await fetch('/ajax?messageCursor=' + String(messageCursor), {
          cache: 'no-store',
          signal: ctrl.signal
        });
        if (resp.status === 503) {
          // Состояние контроллера временно занято (мьютекс/снапшот) - это не обрыв
          // связи само по себе. Но серия 503 не обновляет показания: когда возраст
          // последнего валидного /ajax превышает обычный порог опросов, используем
          // уже существующее состояние устаревших данных.
          runtimeBusyCounter += 1;
          if (runtimeBusyCounter >= offlineThreshold) {
            runtimeBusyCounter = 0;
            activeSinks.message(RUNTIME_BUSY_WARNING, 1);
          }
          if (Date.now() - lastValidTelemetryAt >= offlineThreshold * 2000) {
            activeSinks.connection(true, true);
          }
          return false;
        }
        runtimeBusyCounter = 0;
        if (!resp.ok) {
          activeSinks.connection(true);
          return false;
        }
        data = await resp.json();
      } catch (err) {
        activeSinks.connection(true);
        return false;
      }

      let events;
      try {
        events = validateRuntimeEvents(data);
        const heaterTelemetry = validateHeaterTelemetry(data);
        lastValidTelemetryAt = Date.now();
        activeSinks.connection(false);
        renderFn(data);
        notifyTelemetryListeners(data);
        if (!messageCursorBootstrapped) {
          // Бутстрап (первая загрузка страницы/вкладки): не переигрываем бэклог
          // кольцевого буфера по одному сообщению раз в 2 секунды - сразу переходим
          // на текущий конец очереди, как это уже делает reset_lua_message_cursor().
          // Признак бутстрапа - отдельный флаг, а не messageCursor === 0: на пустом
          // кольце latestSequence тоже 0, курсор не сдвигается, и первое в жизни
          // устройства событие попадало бы сюда же и молча терялось вместе с сиреной
          // (авария без защёлки, например захлёб, живёт только в тексте сообщения).
          messageCursor = heaterTelemetry.latestSequence;
          messageCursorBootstrapped = true;
        } else {
          for (let index = 0; index < events.length; index++) {
            const event = events[index];
            const expected = nextMessageSequence(messageCursor);
            if (event.sequence !== expected) {
              // Кольцо на ESP начинается с 1 после перезагрузки. Вкладка при этом
              // живёт со старым курсором (203 → 1) - это не потеря сообщений, а
              // новый прогон. Настоящий разрыв - только прыжок вперёд: курсор
              // вытеснен из кольца (больше 32 событий между опросами).
              const deviceRestarted = messageCursor !== 0 && event.sequence < expected;
              // Молчать про откат счётчика нельзя: перезагрузка контроллера посреди
              // перегонки - это событие, о котором оператор обязан узнать (нагрев
              // снят, программа восстанавливается из снимка). Прошивка сама о старте
              // не сообщает, поэтому единственный признак - именно откат счётчика.
              if (deviceRestarted) activeSinks.message(MESSAGE_REBOOT_WARNING, 1);
              notifyRuntimePairListeners(null, deviceRestarted ? 'reboot' : 'gap');
            }
            if (event.kind === 'message') {
              const pair = parseRuntimePair(event.text);
              const prefix = event.text.indexOf('报警! ') === 0
                ? '报警! '
                : (event.text.indexOf('警告! ') === 0 ? '警告! ' : '');
              activeSinks.message(pair ? prefix + pair.text : event.text.replace(MESSAGE_TAG_PATTERN, ''), event.level);
              if (pair) notifyRuntimePairListeners(pair, null);
            } else {
              activeSinks.log(
                event.text,
                Object.assign({}, data, { messageSequence: event.sequence })
              );
            }
            messageCursor = event.sequence;
          }
        }
        updateHeaterAlarmLatched(heaterTelemetry.heaterAlarmLatched, heaterTelemetry.reason);
        return true;
      } catch (err) {
        reportUiError(err, activeSinks.message);
        return false;
      }
    } finally {
      clearTimeout(timer);
      telemetryRequestInFlight = false;
    }
  }

  function reportUiError(err, messageSink) {
    console.log('UI update error:', err);
    (messageSink || addMessage)(
      '界面更新错误: ' + (err && err.message ? err.message : err), 1
    );
  }

  function startPollLoop(fn, intervalMs) {
    (async function pollLoop() {
      await fn();
      setTimeout(pollLoop, intervalMs || 2000);
    })();
  }

  async function loadUiBootstrap(applyBootstrap) {
    if (typeof applyBootstrap !== 'function') {
      throw new Error('未设置初始数据处理程序.');
    }
    if (bootstrapStarted) {
      showRequestError('初始数据已加载.');
      return false;
    }
    bootstrapStarted = true;
    bootstrapPending = true;
    document.body.inert = true;
    let response;
    try {
      response = await fetch('/ui-bootstrap', { cache: 'no-store' });
    } catch (err) {
      showRequestError('加载初始数据时网络错误.');
      return false;
    }
    if (!response.ok) {
      showRequestError('初始数据不可用: HTTP ' + response.status + '.');
      return false;
    }
    let data;
    try {
      data = await response.json();
    } catch (err) {
      showRequestError('初始数据JSON无效.');
      return false;
    }
    if (!validateUiBootstrap(data)) {
      showRequestError('初始数据无效.');
      return false;
    }
    try {
      applyBootstrap(data);
      const scheme = byId('sec-scheme');
      if (scheme) {
        const schemeColumn = scheme.closest('.col-center');
        const modeGrid = scheme.closest('.grid');
        scheme.hidden = data.hideProcessScheme;
        if (schemeColumn) schemeColumn.hidden = data.hideProcessScheme;
        if (modeGrid) modeGrid.classList.toggle('grid-without-scheme', data.hideProcessScheme);
      }
    } catch (err) {
      showRequestError('初始数据无效: ' +
        (err && err.message ? err.message : err));
      return false;
    }
    bootstrapPending = false;
    document.body.inert = false;
    return true;
  }

  function startTelemetryPage(renderFn, options) {
    if (typeof renderFn !== 'function') {
      throw new Error('未设置处理程序 telemetry response.');
    }
    const pageOptions = options || {};
    Object.keys(pageOptions).forEach(function (key) {
      if (TELEMETRY_OPTION_KEYS.indexOf(key) === -1) {
        throw new Error('未知选项 telemetry lifecycle: ' + key);
      }
    });
    if (pageOptions.threshold !== undefined &&
        (!Number.isInteger(pageOptions.threshold) || pageOptions.threshold < 1)) {
      throw new Error('threshold 必须是正整数.');
    }
    if (pageOptions.onReady !== undefined && typeof pageOptions.onReady !== 'function') {
      throw new Error('onReady 必须是函数.');
    }
    if (pageOptions.storeMessageHistory !== undefined &&
        typeof pageOptions.storeMessageHistory !== 'boolean') {
      throw new Error('storeMessageHistory 必须为 boolean.');
    }
    if (pageOptions.dynamicThemeTitle !== undefined &&
        typeof pageOptions.dynamicThemeTitle !== 'boolean') {
      throw new Error('dynamicThemeTitle 必须为 boolean.');
    }
    if (pageOptions.implicitSystemTheme !== undefined &&
        typeof pageOptions.implicitSystemTheme !== 'boolean') {
      throw new Error('implicitSystemTheme 必须为 boolean.');
    }
    if (pageOptions.onLastMessageRemoved !== undefined &&
        typeof pageOptions.onLastMessageRemoved !== 'function') {
      throw new Error('onLastMessageRemoved 必须是函数.');
    }
    if (pageOptions.onConnectionChange !== undefined &&
        typeof pageOptions.onConnectionChange !== 'function') {
      throw new Error('onConnectionChange 必须是函数.');
    }
    if (pageOptions.connectionIds !== undefined) {
      const ids = pageOptions.connectionIds;
      if (!ids || Object.keys(ids).length !== 2 ||
          typeof ids.online !== 'string' || typeof ids.offline !== 'string' ||
          !byId(ids.online) || !byId(ids.offline)) {
        throw new Error('未找到必需的指示器 telemetry connection.');
      }
    } else if (!byId('connection_indicator')) {
      throw new Error('未找到必需元素 #connection_indicator.');
    }
    if (telemetryPageStarted) {
      throw new Error('Telemetry lifecycle 已在运行.');
    }

    telemetryPageStarted = true;
    storeMessageHistory = pageOptions.storeMessageHistory !== false;
    onLastMessageRemoved = pageOptions.onLastMessageRemoved || null;
    onConnectionChange = pageOptions.onConnectionChange || null;
    bindPageLock();
    init({
      threshold: pageOptions.threshold || 3,
      connectionIds: pageOptions.connectionIds,
      dynamicThemeTitle: pageOptions.dynamicThemeTitle === true,
      implicitSystemTheme: pageOptions.implicitSystemTheme === true
    });
    if (pageOptions.onReady) pageOptions.onReady();
    startPollLoop(function () { return pollAjax(renderFn); }, 2000);
  }

  function commandResultText(token, body) {
    const entry = COMMAND_TOKENS[token];
    if (entry) return entry;
    return { ok: false, level: 0, text: body || '未知的命令响应.' };
  }

  function sendCommand(command, options) {
    assertOnline();
    return sendCommandRequest(command, options);
  }

  async function sendCommandRequest(command, options) {
    try {
      assertOnline();
      const commandBody = command.indexOf('=') === -1 ? command + '=1' : command;
      const resp = await fetch('/command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: commandBody
      });
      const body = plainBodyText(await resp.text());
      // Отказы приходят конвертом, где токен лежит в error; успех - по-прежнему текстом.
      // Читаем тело один раз и достаём из той формы, в которой оно пришло, две разные
      // вещи: token - чтобы распознать штатный отказ раньше общей HTTP-ошибки, detail -
      // чтобы показать человеку текст, а не сырой JSON.
      let token = body;
      let detail = body;
      if ((resp.headers.get('Content-Type') || '').indexOf('application/json') !== -1) {
        try {
          const parsed = JSON.parse(body);
          if (parsed && typeof parsed === 'object') {
            if (parsed.error) token = String(parsed.error);
            detail = errorEnvelopeText(parsed);
          }
        } catch (e) {
          // Битый JSON - оставляем тело как есть, ниже оно уйдёт в общую ветку HTTP-ошибки.
        }
      }
      token = token || (resp.ok ? 'OK' : '');
      const result = commandResultText(token, detail);
      const knownToken = token && Object.prototype.hasOwnProperty.call(COMMAND_TOKENS, token);
      function report(text, level) {
        addMessage(text, level);
      }
      if (knownToken && !result.ok) {
        showRequestError(result.text);
        report(result.text, result.level);
        return false;
      }
      if (!resp.ok) {
        const errorText = '命令错误 HTTP ' + resp.status + ': ' + (detail || resp.statusText);
        showRequestError(errorText);
        report(errorText, 0);
        return false;
      }
      if (knownToken && result.ok) {
        clearRequestError();
        if (options && options.successMessage) report(options.successMessage, 2);
        return true;
      }
      addMessage(result.text, result.level);
      return false;
    } catch (err) {
      const errorText = '发送命令时网络错误: ' + err;
      showRequestError(errorText);
      addMessage(errorText, 0);
      return false;
    }
  }

  async function sendNumericCommand(action, inputOrId, spec, options) {
    const result = readNumericInput(inputOrId, spec);
    if (!result) return false;
    return sendCommand(action + '=' + encodeURIComponent(result.text), options);
  }

  function sendPowerCommand(inputOrId, powerUnit, maxValue, options) {
    if (!Number.isFinite(maxValue) || maxValue <= 0) {
      showRequestError('未从控制器获得有效的功率上限.');
      return Promise.resolve(false);
    }
    return sendNumericCommand('voltage', inputOrId, {
      label: powerUnit === 'P' ? '功率' : '电压',
      min: 0,
      max: maxValue
    }, options);
  }

  function hasExactKeys(value, expectedKeys) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
    const actualKeys = Object.keys(value).sort();
    const sortedExpected = expectedKeys.slice().sort();
    if (actualKeys.length !== sortedExpected.length) return false;
    return actualKeys.every(function (key, index) { return key === sortedExpected[index]; });
  }

  function validateUiBootstrap(data) {
    const expectedKeys = data.timeZone === undefined ? UI_BOOTSTRAP_KEYS : UI_BOOTSTRAP_KEYS.concat('timeZone');
    if (!hasExactKeys(data, expectedKeys)) return false;
    for (let index = 0; index < UI_BOOTSTRAP_STRING_KEYS.length; index++) {
      if (typeof data[UI_BOOTSTRAP_STRING_KEYS[index]] !== 'string') return false;
    }
    if (descriptionByteLength(data.description) > 250) return false;
    if (!Array.isArray(data.i2cSteppers) || data.i2cSteppers.length !== 10) return false;
    for (let index = 0; index < UI_BOOTSTRAP_BOOLEAN_KEYS.length; index++) {
      if (typeof data[UI_BOOTSTRAP_BOOLEAN_KEYS[index]] !== 'boolean') return false;
    }
    for (let index = 0; index < UI_BOOTSTRAP_INTEGER_KEYS.length; index++) {
      if (!Number.isSafeInteger(data[UI_BOOTSTRAP_INTEGER_KEYS[index]])) return false;
    }
    if (data.timeZone !== undefined && (!Number.isSafeInteger(data.timeZone) || data.timeZone < 0 || data.timeZone > 23)) return false;
    for (let index = 0; index < UI_BOOTSTRAP_NUMBER_KEYS.length; index++) {
      if (!Number.isFinite(data[UI_BOOTSTRAP_NUMBER_KEYS[index]])) return false;
    }
    if (data.mode < 0 || data.mode > 7) return false;
    if (['allinone', 'herms', 'rims'].indexOf(data.beerBrewOrder) === -1 ||
        ['local', 'i2c'].indexOf(data.calibrationPump) === -1 ||
        ['pump', 'two-valves', 'unavailable'].indexOf(data.cheeseCoolingScheme) === -1) return false;
    return true;
  }

  function validateOperationPayload(value, expectedKeys, expectedOperationId, context) {
    if (!hasExactKeys(value, expectedKeys) ||
        !Number.isInteger(value.operationId) || value.operationId <= 0 ||
        value.operationId > 0xFFFFFFFF ||
        typeof value.state !== 'string' || typeof value.error !== 'string' ||
        !['queued', 'running', 'succeeded', 'failed'].includes(value.state) ||
        (expectedOperationId !== undefined && value.operationId !== expectedOperationId) ||
        (value.state === 'failed' ? value.error === 'none' || value.error === '' : value.error !== 'none')) {
      throw new Error('契约无效 ' + context + '.');
    }
    return value;
  }

  async function readOperationAcceptance(resp) {
    // Отказ (4xx/5xx) несёт причину в теле: показываем её, а не голый номер статуса.
    if (resp && !resp.ok) throw new Error(await responseErrorText(resp));
    if (!resp || resp.status !== 202) {
      throw new Error('操作的HTTP状态无效: ' + (resp ? resp.status : 0) + '.');
    }
    let result;
    try {
      result = await resp.json();
    } catch (err) {
      throw new Error('操作的JSON响应无效.');
    }
    validateOperationPayload(
      result,
      ['operationId', 'state', 'error'],
      undefined,
      '操作响应'
    );
    if (result.state !== 'queued' || result.error !== 'none') {
      throw new Error('操作未被确认为 queued.');
    }
    return result;
  }

  async function waitForOperation(operationId) {
    if (!Number.isInteger(operationId) || operationId <= 0 || operationId > 0xFFFFFFFF) {
      throw new Error('操作ID无效.');
    }
    const startedAt = Date.now();
    let lastPollBusy = false;
    while (Date.now() - startedAt < OPERATION_TIMEOUT_MS) {
      let resp;
      let receivedResponse = false;
      const controller = new AbortController();
      const remainingMs = OPERATION_TIMEOUT_MS - (Date.now() - startedAt);
      const timer = setTimeout(function () { controller.abort(); }, remainingMs);
      try {
        resp = await fetch('/ajax?operationId=' + encodeURIComponent(String(operationId)), {
          cache: 'no-store',
          signal: controller.signal
        });
        receivedResponse = true;
        if (resp.status === 503) {
          let busy;
          try {
            busy = await resp.json();
          } catch (err) {
            if (controller.signal.aborted || (err && err.name === 'AbortError')) throw err;
            throw new Error('操作的HTTP 503 JSON响应无效 ' + operationId + '.');
          }
          if (!hasExactKeys(busy, ['operationId', 'error']) ||
              busy.operationId !== operationId || busy.error !== 'operation_store_busy') {
            throw new Error('操作的HTTP 503契约无效 ' + operationId + '.');
          }
          lastPollBusy = true;
        } else {
          lastPollBusy = false;
          if (resp.status === 404) {
            throw new Error('操作 ' + operationId + ' 未找到，或其结果已过期 (HTTP 404).');
          }
          if (!resp.ok) {
            const errorText = await responseErrorText(resp, '操作检查错误 ' + operationId);
            if (controller.signal.aborted) throw new DOMException('aborted', 'AbortError');
            throw new Error(errorText);
          }
          let result;
          try {
            result = await resp.json();
          } catch (err) {
            if (controller.signal.aborted || (err && err.name === 'AbortError')) throw err;
            throw new Error('操作的/ajax JSON响应无效 ' + operationId + '.');
          }
          validateOperationPayload(
            result,
            ['operationId', 'state', 'error'],
            operationId,
            '/ajax 对于操作 ' + operationId
          );
          if (result.state === 'succeeded') return result;
          if (result.state === 'failed') {
            throw new Error('操作 ' + operationId + ' 以错误结束: ' + operationErrorText(result.error) + '.');
          }
        }
      } catch (err) {
        if (controller.signal.aborted || (err && err.name === 'AbortError')) {
          throw new Error('操作 ' + operationId + ' 未在45秒内完成.');
        }
        if (!receivedResponse) {
          throw new Error('检查操作时网络错误 ' + operationId + ': ' + err);
        }
        throw err;
      } finally {
        clearTimeout(timer);
      }
      await new Promise(function (resolve) { setTimeout(resolve, OPERATION_POLL_INTERVAL_MS); });
    }
    throw new Error(
      '操作 ' + operationId + ' 未在45秒内完成' +
      (lastPollBusy ? ' (最后响应 HTTP 503).' : '.')
    );
  }

  async function requestI2cPump(url, fallbackText) {
    const ctrl = new AbortController();
    const timer = setTimeout(function () { ctrl.abort(); }, 4000);
    try {
      assertOnline();
      const resp = await fetch(url, { cache: 'no-store', signal: ctrl.signal });
      if (!resp.ok) {
        showRequestError(await responseErrorText(resp, fallbackText));
        return false;
      }
      clearRequestError();
      return true;
    } catch (err) {
      showRequestError(String(err && err.message ? err.message : err));
      return false;
    } finally {
      clearTimeout(timer);
    }
  }

  async function sendI2cPump() {
    const speed = readNumericInput('i2c_speed', { label: '采出速度', exclusiveMin: 0 });
    if (!speed) return false;
    const volume = readNumericInput('i2c_volume', { label: '体积', exclusiveMin: 0, max: 65535 });
    if (!volume) return false;
    const url = '/i2cpump?speed=' + encodeURIComponent(speed.text) +
      '&volume=' + encodeURIComponent(volume.text);
    return requestI2cPump(url, 'I2C-泵未接受命令');
  }

  async function stopI2cPump() {
    return requestI2cPump('/i2cpump?stop=1', 'I2C-泵未接受停止命令');
  }

  async function readProgramResponse(resp) {
    let result;
    try {
      result = await resp.json();
    } catch (err) {
      throw new Error('JSON响应无效 /program.');
    }
    const baseKeys = ['ok', 'err', 'program'];
    const acceptedKeys = baseKeys.concat(['operationId', 'state', 'error']);
    if (!hasExactKeys(result, resp.status === 202 ? acceptedKeys : baseKeys) ||
        typeof result.ok !== 'boolean' ||
        typeof result.err !== 'string' ||
        typeof result.program !== 'string') {
      throw new Error('契约无效 /program.');
    }
    if (!resp.ok && result.ok) {
      throw new Error('HTTP状态无效 /program: ' + resp.status);
    }
    if (result.ok && resp.status !== 200 && resp.status !== 202) {
      throw new Error('HTTP状态无效 /program: ' + resp.status);
    }
    if (resp.status === 202) {
      if (!result.ok) throw new Error('契约无效 /program.');
      validateOperationPayload(result, acceptedKeys, undefined, '/program');
      if (result.state !== 'queued' || result.error !== 'none') {
        throw new Error('操作/program未被确认为 queued.');
      }
    }
    // Отказ постановки в очередь приходит коротким признаком; страницы показывают err как есть.
    result.err = operationErrorText(result.err);
    result.httpStatus = resp.status;
    result.queued = result.ok && resp.status === 202;
    return result;
  }

  function postProgram(form) {
    assertOnline();
    return postProgramRequest(form);
  }

  async function postProgramRequest(form) {
    const body = new FormData();
    const allowedFields = ['WProgram', 'Descr'];
    for (let i = 0; i < allowedFields.length; i++) {
      const name = allowedFields[i];
      const fields = form.querySelectorAll('[name="' + name + '"]');
      if (fields.length > 1) {
        const err = '字段 «' + name + '» 重复.';
        showRequestError(err);
        return { ok: false, err: err, program: '', httpStatus: 0, queued: false };
      }
      if (fields.length === 0 || fields[0].disabled) continue;
      if (name === 'Descr') {
        const byteLength = descriptionByteLength(fields[0].value);
        if (byteLength > 250) {
          const err = '描述超过250字节.';
          showRequestError(err);
          return { ok: false, err: err, program: '', httpStatus: 0, queued: false };
        }
      }
      body.append(name, fields[0].value);
    }
    if (Array.from(body.keys()).length === 0) {
      const err = '没有数据用于 /program.';
      showRequestError(err);
      return { ok: false, err: err, program: '', httpStatus: 0, queued: false };
    }
    if (programMutationPending) {
      const err = '程序更改已在进行中.';
      showRequestError(err);
      return { ok: false, err: err, program: '', httpStatus: 0, queued: false };
    }
    const submittedProgramRevision = programRevision;
    programMutationPending = true;
    try {
      assertOnline();
      const resp = await fetch('/program', { method: 'POST', body: body });
      const result = await readProgramResponse(resp);
      if (!result.ok) {
        showRequestError('/program: HTTP ' + result.httpStatus + ' — ' + (result.err || '请求未被接受'));
        return result;
      }
      if (!result.queued) throw new Error('服务器未确认程序已加入队列.');
      await waitForOperation(result.operationId);
      result.queued = false;
      result.state = 'succeeded';
      clearRequestError();
      markProgramSaved(submittedProgramRevision);
      return result;
    } catch (err) {
      const message = String(err && err.message ? err.message : err);
      showRequestError(message);
      return { ok: false, err: message, program: '', httpStatus: 0, queued: false };
    } finally {
      programMutationPending = false;
    }
  }

  async function clearProgram() {
    if (!confirm('清除当前程序?')) return false;
    if (programMutationPending) {
      const message = '程序更改已在进行中.';
      showRequestError(message);
      notify(message, 1);
      return false;
    }
    const body = new FormData();
    body.append('clear', '1');
    programMutationPending = true;
    try {
      assertOnline();
      const resp = await fetch('/program', { method: 'POST', body: body });
      const result = await readProgramResponse(resp);
      if (!result.ok) {
        const failText =
          '清除未被接受 (HTTP ' + result.httpStatus + '): ' +
            (result.err || '未知错误');
        notify(
          failText,
          result.httpStatus === 400 || result.httpStatus === 409 || result.httpStatus === 503 ? 1 : 0
        );
        showRequestError('/program: HTTP ' + result.httpStatus + ' — ' + (result.err || '清除未被接受'));
        return false;
      }
      if (!result.queued) throw new Error('服务器未确认清除已加入队列.');
      await waitForOperation(result.operationId);
      clearRequestError();
      markProgramSaved();
      notify('程序已清除.', 2);
      return true;
    } catch (err) {
      const message = '程序清除错误: ' + err;
      showRequestError(message);
      notify(message, 0);
      return false;
    } finally {
      programMutationPending = false;
    }
  }

  function addLuaButtons() {
    let btnList = '';
    const luaBtnEl = byId('samovar_lua_btn_list');
    if (luaBtnEl) {
      try {
        const parsed = JSON.parse(luaBtnEl.textContent || '""');
        if (typeof parsed === 'string') btnList = parsed;
      } catch (err) {
        btnList = '';
      }
    }
    if (btnList === '') return;
    const line = byId('lua_btn_ln');
    const block = byId('lua_btn');
    if (!line || !block) return;
    btnList.split(',').forEach(function (item, index) {
      if (item === '') return;
      const parts = item.split('|');
      const btn = document.createElement('input');
      btn.type = 'button';
      btn.name = 'luabtn' + index;
      btn.value = parts[1] || parts[0];
      btn.className = 'button';
      btn.addEventListener('click', function () { runLua(parts[0]); });
      line.appendChild(btn);
      block.style.visibility = 'visible';
    });
  }

  function runLua(num) {
    sendCommand('lua=' + encodeURIComponent(num));
  }

  function runLuaString() {
    const input = byId('lua_str_i');
    if (!input) return;
    sendCommand('luastr=' + encodeURIComponent(input.value));
  }


  // ==================== Мнемосхема и карточки (новый интерфейс) ====================
  // Разметка описывает привязки атрибутами, а не id: data-tele="Ключ" (текст, data-fmt -
  // число знаков), data-on="Ключ" (класс is-on при истинном значении), data-show="Ключ"
  // (класс is-hidden при ложном), data-width="Ключ" (ширина в процентах),
  // data-jar="i" (i-я из трёх банок окна вокруг текущей ёмкости, см. jarWindow).
  // Ключи - поля /ajax плюс производные с подчёркиванием (см. deriveView).
  const telemetryListeners = [];
  const runtimePairListeners = [];

  function onTelemetry(fn) {
    if (typeof fn === 'function') telemetryListeners.push(fn);
  }

  function notifyTelemetryListeners(data) {
    telemetryListeners.forEach(function (fn) {
      try { fn(data); } catch (err) { console.error('telemetry listener', err); }
    });
  }

  function onRuntimePair(fn) {
    if (typeof fn === 'function') runtimePairListeners.push(fn);
  }

  function notifyRuntimePairListeners(pair, discontinuity) {
    runtimePairListeners.forEach(function (fn) {
      try { fn(pair, discontinuity); } catch (err) { console.error('runtime pair listener', err); }
    });
  }

  const LINE_TYPE_NAMES = {
    rect: { H: '酒头', B: '酒心', P: '暂停', T: '酒尾', C: '预液泛' },
    dist: { T: '按釜温', S: '釜内酒精，相对.', A: '釜内酒精，绝对.', P: '蒸汽中酒精，绝对.', R: '蒸汽中酒精，相对.' },
    bk: { T: '按釜温', S: '釜内酒精，相对.', A: '釜内酒精，绝对.', P: '蒸汽中酒精，绝对.', R: '蒸汽中酒精，相对.' },
    nbk: { H: '预热', S: '设置', O: '优化', W: '工作' },
    beer: { M: '投入麦芽', P: '暂停', B: '煮沸', C: '冷却', W: '等待', F: '发酵', L: 'Lua', A: '自整定' },
    cheese: { H: '加热', P: '保温', C: '冷却', M: '搅拌', D: '加料', N: '等待 pH', W: '手动操作', S: '排放', F: '絮凝', L: 'Lua' }
  };

  function schemeKind() {
    return (document.body && document.body.getAttribute('data-scheme')) || 'rect';
  }

  function programLines() {
    const textarea = byId('WProgram');
    if (!textarea) return [];
    return String(textarea.value || '').split('\n')
      .map(function (line) { return line.trim(); })
      .filter(function (line) { return line !== ''; });
  }

  function num(value) {
    const n = Number(value);
    return Number.isFinite(n) ? n : null;
  }

  function hoursText(hours) {
    if (!Number.isFinite(hours) || hours <= 0) return '—';
    const total = Math.round(hours * 60);
    const h = Math.floor(total / 60);
    const m = total % 60;
    return h > 0 ? h + ' h ' + (m < 10 ? '0' : '') + m + ' min' : m + ' min';
  }

  // Разбор строки программы по формату режима. Поля, которых в формате нет, остаются null.
  function parseProgramLine(kind, line) {
    const f = line.split(';').map(function (s) { return s.trim(); });
    const names = LINE_TYPE_NAMES[kind] || {};
    const row = { type: f[0] || '', name: names[f[0]] || f[0] || '—', volume: null, speed: null,
      capacity: null, temp: null, power: null, value: null, time: null, steam: null, summary: '' };
    if (kind === 'rect') {
      // Ёмкости нумеруются с 0, поэтому 0 — настоящая ёмкость; у паузы поле — заполнитель, ёмкости нет.
      row.volume = num(f[1]); row.speed = num(f[2]); row.capacity = row.type === 'P' ? null : num(f[3]);
      row.temp = num(f[4]); row.power = num(f[5]);
      if (row.type === 'P') row.time = row.volume !== null ? row.volume / 3600 : null;
      else if (row.volume !== null && row.speed > 0) row.time = row.volume / (row.speed * 1000);
      row.summary = row.type === 'P'
        ? row.name + ' · ' + (row.volume !== null ? row.volume + ' s' : '')
        : row.name + ' · ' + (row.volume !== null ? row.volume + ' ml' : '') +
          (row.speed !== null ? ' · ' + row.speed + ' l/h' : '') +
          (row.capacity !== null ? ' · 容量. ' + row.capacity : '');
    } else if (kind === 'dist' || kind === 'bk') {
      row.value = num(f[1]); row.capacity = num(f[2]); row.power = num(f[3]); row.steam = num(f[4]);
      row.summary = row.name + (row.value !== null ? ' · ' + row.value : '') +
        (row.capacity !== null ? ' · 容量. ' + row.capacity : '');
    } else if (kind === 'beer' || kind === 'cheese') {
      // Время строки в минутах, у строки L - тайм-аут в секундах.
      row.temp = num(f[1]); row.time = num(f[2]) !== null ? num(f[2]) / (row.type === 'L' ? 3600 : 60) : null;
      row.summary = row.name + (row.temp ? ' · ' + row.temp + ' °C' : '') +
        (row.time ? ' · ' + hoursText(row.time) : '');
    } else if (kind === 'nbk') {
      row.speed = num(f[1]); row.power = num(f[2]);
      row.summary = row.name + (row.speed !== null ? ' · ' + row.speed + ' l/h' : '') +
        (row.power !== null ? ' · ' + row.power : '');
    } else {
      row.summary = line;
    }
    return row;
  }

  // Короткие имена типов строк для подписи под банками.
  const JAR_TYPE_NAMES = {
    rect: { H: '酒头', B: '酒心', P: '暂停', T: '酒尾', C: '预液泛' },
    dist: { T: '按釜温', S: '釜，相对.', A: '釜，绝对.', P: '蒸汽，绝对.', R: '蒸汽，相对.' },
    bk: { T: '按釜温', S: '釜，相对.', A: '釜，绝对.', P: '蒸汽，绝对.', R: '蒸汽，相对.' }
  };

  // Окно из трёх банок вокруг фактической ёмкости: предыдущая, текущая, следующая.
  // У края окно сдвигается, чтобы банок было три. Банки — разные ёмкости программы в порядке
  // первого упоминания, подпись — тип первой строки с этой ёмкостью (у текущей — тип текущей строки).
  // Без программы показываем банки 0–2; без фактической ёмкости сохраняем выбор по строке.
  function jarWindow(kind, lines, lineNum, currentCapacity) {
    const names = JAR_TYPE_NAMES[kind] || {};
    const jars = [];
    lines.forEach(function (line) {
      const row = parseProgramLine(kind, line);
      if (row.capacity !== null && !jars.some(function (j) { return j.num === row.capacity; })) {
        jars.push({ num: row.capacity, type: names[row.type] || row.type, active: false });
      }
    });
    if (!jars.length) [0, 1, 2].forEach(function (n) { jars.push({ num: n, type: '', active: false }); });
    const row = lineNum ? parseProgramLine(kind, lines[lineNum - 1]) : null;
    const selected = currentCapacity != null ? currentCapacity : row && row.capacity;
    if (selected != null && !jars.some(function (j) { return j.num === selected; })) {
      jars.push({ num: selected, type: '', active: false });
    }
    let idx = selected != null ? jars.findIndex(function (j) { return j.num === selected; }) : -1;
    if (idx >= 0) {
      jars[idx].active = true;
      if (row && row.capacity === selected) jars[idx].type = names[row.type] || row.type;
    }
    const start = Math.max(0, Math.min(idx < 0 ? 0 : idx - 1, jars.length - 3));
    return jars.slice(start, start + 3);
  }

  function deriveView(data) {
    const kind = schemeKind();
    const v = Object.assign({}, data);
    const steam = num(data.SteamTemp), pipe = num(data.PipeTemp);
    v._delta = steam !== null && pipe !== null ? pipe - steam : null;
    const bodySteam = num(data.BodyTemp_Steam), bodyPipe = num(data.BodyTemp_Pipe);
    v._steamSet = bodySteam > 0 ? bodySteam : null;
    v._pipeSet = bodyPipe > 0 ? bodyPipe : null;
    v._steamDev = v._steamSet !== null && steam !== null ? steam - v._steamSet : null;
    v._pipeDev = v._pipeSet !== null && pipe !== null ? pipe - v._pipeSet : null;
    v._heaterOn = Number(data.PowerOn) === 1;
    v._paused = Number(data.PauseOn) === 1 || Number(data.BeerManualPause) === 1;
    v._running = v._heaterOn && !v._paused;
    // При втором насосе на головах локальный тракт отбора остановлен.
    v._cp = kind === 'rect' && !!Number(data.i2c_second_pump);
    v._noCp = !v._cp;
    // На головах с ЦП прошивка кладёт в ActualVolumePerHour скорость насоса голов,
    // а основной насос стоит: его подпись — 0, скорость голов — фактическая ISspd.
    const cpHeads = v._cp && data.PrgType === 'H';
    v._withdrawing = Number(data.WthdrwlStatus) > 0 && !v._paused && !cpHeads;
    v._mainRate = cpHeads ? 0 : data.ActualVolumePerHour;
    const rate = num(v._mainRate);
    const i2cPumpOn = Number(data.i2c_pump_running) === 1;
    v._pumpOn = kind === 'nbk' ? (num(data.ISspd) > 0 && v._running) || i2cPumpOn
      : kind === 'beer' || kind === 'cheese' ? (!!data.mixer && v._running) || i2cPumpOn
      : v._cp ? v._withdrawing && rate > 0
      : (v._withdrawing && rate > 0) || i2cPumpOn;
    const i2cMixerPresent = Number(data.i2c_mixer_present) === 1;
    const i2cMixerRunning = Number(data.i2c_mixer_running) === 1;
    v._mixerOn = !!data.mixer && v._running && (!i2cMixerPresent || i2cMixerRunning);
    // Второй I2C-насос отбора голов над ЦП (ректификация): ЦП и насос на схеме только
    // если он включён в настройках и плата отвечает; анимация — пока насос качает.
    v._cpPumpOn = v._cp && !!Number(data.i2c_second_pump_running);
    // Варочный порядок пива (BeerBrewOrder): у HERMS/RIMS вместо мешалки — насос
    // рециркуляции и бойлер/труба с ТЭНом; сыр и су-вид всегда рисуют обычный котёл.
    const order = kind === 'beer' ? String(data.BeerBrewOrder || '') : '';
    v._herms = order === 'herms';
    v._rims = order === 'rims';
    v._recirc = v._herms || v._rims;
    v._allinone = !v._recirc;
    // Вода охлаждения: по клапану (valve_status прошивки) или работающему ШИМ-насосу.
    // У старой прошивки ключа valve нет — тогда, как раньше, по нагреву.
    v._flowOn = data.valve === undefined ? v._heaterOn : (!!data.valve || num(data.wp_spd) > 0);
    const unit = typeof window.pwr_unit === 'string' ? window.pwr_unit : 'V';
    const volt = num(data.current_power_volt), watt = num(data.current_power_p);
    v._powerUnit = unit === 'P' ? 'W' : 'V';
    v._powerValue = unit === 'P' ? watt : volt;
    v._heaterText = !v._heaterOn ? '关闭'
      : unit === 'P' ? (watt !== null ? watt + ' W' : '—')
      : (volt !== null ? volt + ' V' : '—') + (watt !== null ? ' · ' + watt + ' W' : '');
    v._cubePressure = num(data.prvl);
    v._pressureLabel = v._cubePressure !== null ? '釜内' : '启动时';
    v._pressureAlt = v._cubePressure !== null ? v._cubePressure : num(data.start_pressure);
    v._alcCube = typeof data.alc === 'number' && Number.isFinite(data.alc) && data.alc >= 0
      ? data.alc : null;
    const ds = Number(data.DetectorStatus);
    const detIdle = Number(data.DetectorIdle);
    v._detectorText = !data.useDetector ? '关'
      : data.PrgType === 'H' ? '观察中'
      : detIdle === 5 ? '⏳ 等待蒸汽'
      : detIdle === 3 || detIdle === 4 || detIdle === 6 ? '⏳ 等待'
      : detIdle === 7 ? '⏸ 暂停'
      : detIdle === 8 ? '观察中'
      : detIdle === 1 ? '—'
      : ds === 0 ? '● 稳定' : ds === 1 ? (data.useautospeed ? '▲ 正在降低速度' : '▲ 上升') : ds === 2 ? '■ 穿透' : '—';
    v._alcSteam = typeof data.stm_alc === 'number' && Number.isFinite(data.stm_alc) && data.stm_alc >= 0
      ? data.stm_alc : null;

    const lines = programLines();
    const n = Number(data.ProgramNum) || 0;
    v._lineTotal = lines.length;
    v._lineNum = n > 0 && n <= lines.length ? n : null;
    const row = v._lineNum ? parseProgramLine(kind, lines[n - 1]) : null;
    const nextRow = v._lineNum && n < lines.length ? parseProgramLine(kind, lines[n]) : null;
    v._lineType = row ? row.type : '';
    v._lineName = row ? row.name : (lines.length ? '等待' : '无程序');
    v._lineCap = row && row.capacity !== null ? row.capacity : null;
    v._jars = jarWindow(kind, lines, v._lineNum, num(data.currentCapacity));
    v._lineCapText = v._lineCap !== null ? '容量 ' + v._lineCap : '';
    v._lineVolume = row ? row.volume : null;
    v._lineSpeed = row ? row.speed : null;
    v._linePower = row && row.power ? row.power : null;
    v._lineTemp = row ? row.temp : null;
    v._lineValue = row ? row.value : null;
    v._lineSteam = row && row.steam ? row.steam : null;
    v._lineTime = row ? hoursText(row.time) : '—';
    v._lineOf = v._lineNum ? v._lineNum + ' / ' + lines.length : (lines.length ? '0 / ' + lines.length : '—');
    v._next = nextRow ? (n + 1) + ' · ' + nextRow.summary : (row ? '最后一行' : '—');
    const progress = num(data.WthdrwlProgress);
    v._progress = progress !== null ? Math.max(0, Math.min(100, progress)) : 0;
    return v;
  }

  function fmtValue(el, value) {
    if (value === undefined || value === null || value === '') return '—';
    if (typeof value === 'number') {
      const digits = el.getAttribute('data-fmt');
      const text = digits !== null ? value.toFixed(Number(digits)) : String(value);
      return el.hasAttribute('data-sign') && value > 0 ? '+' + text : text;
    }
    if (typeof value === 'boolean') return value ? '是' : '否';
    return String(value);
  }

  function renderScheme(data) {
    const v = deriveView(data);
    const all = document.querySelectorAll('[data-tele],[data-on],[data-show],[data-width],[data-jar]');
    for (let i = 0; i < all.length; i++) {
      const el = all[i];
      const key = el.getAttribute('data-tele');
      if (key !== null) el.textContent = fmtValue(el, v[key]);
      const onKey = el.getAttribute('data-on');
      if (onKey !== null) el.classList.toggle('is-on', !!v[onKey]);
      const showKey = el.getAttribute('data-show');
      if (showKey !== null) el.classList.toggle('is-hidden', !v[showKey]);
      const widthKey = el.getAttribute('data-width');
      if (widthKey !== null) {
        const w = num(v[widthKey]);
        el.style.width = (w === null ? 0 : Math.max(0, Math.min(100, w))) + '%';
      }
      const jar = el.getAttribute('data-jar');
      if (jar !== null) {
        const j = v._jars[Number(jar)];
        el.classList.toggle('is-hidden', !j);
        el.classList.toggle('is-on', !!j && j.active);
        const numEl = el.querySelector('.jar-num'), typeEl = el.querySelector('.jar-type');
        if (numEl) numEl.textContent = j ? String(j.num) : '';
        if (typeEl) typeEl.textContent = j ? j.type : '';
        // Заливка текущей банки — процент отбора по строке (вся банка = 100 %).
        const body = el.querySelector('.jar'), fill = el.querySelector('.jar-fill');
        if (body && fill) {
          const inner = Number(body.getAttribute('height')) - 4;
          const fillH = j && j.active ? inner * v._progress / 100 : 0;
          fill.setAttribute('height', String(fillH));
          fill.setAttribute('y', String(2 + inner - fillH));
        }
      }
    }
    return v;
  }

  onTelemetry(renderScheme);

  // Шапка таблицы программы (все режимы). Поля строки на десктопе стоят подряд с
  // фиксированной шириной, а ячейки шапки раньше раскладывались процентами или
  // неразрывными пробелами и уезжали от своих колонок. Выравниваем шапку по первой
  // строке данных: каждой ячейке шапки - отступ и ширина соответствующего поля.
  // На телефоне (поля переносятся в две колонки) inline-стили снимаются.
  const PROGRAM_HEADER_SELECTOR = '#hdr, #cheeseProgramHeader';

  function programRowCells(row) {
    return Array.prototype.filter.call(row.children, function (el) {
      if (el.tagName === 'BUTTON' || el.type === 'hidden' || el.offsetWidth === 0) return false;
      return !(el.tagName === 'SPAN' && el.textContent.trim() === '');
    });
  }

  function programHeaderLabelText(cell) {
    const label = cell.tagName === 'LABEL' ? cell : (cell.querySelector('label') || cell);
    const copy = label.cloneNode(true);
    copy.querySelectorAll('.tooltiptext').forEach(function (t) { t.remove(); });
    return copy.textContent.trim();
  }

  // Телефон: шапка скрыта, у каждого поля своя подпись, строка - сетка «подпись-поле»
  // по две пары в линию. Всё, что вставлено/переопределено, снимается в clearProgramRowMobile().
  function applyProgramRowMobile(row, labels) {
    row.setAttribute('data-prg-mob', '1');
    // Пробельный текст между элементами (в nbk.htm - &nbsp;) в сетке становится
    // отдельной ячейкой; убираем его и возвращаем в clearProgramRowMobile.
    row._prgText = [];
    Array.prototype.slice.call(row.childNodes).forEach(function (n) {
      if (n.nodeType === 3 && !n.textContent.replace(/[\s\u00a0]/g, '')) {
        row._prgText.push([n, n.nextSibling]);
        n.remove();
      }
    });
    row.style.display = 'grid';
    row.style.gridTemplateColumns = 'max-content minmax(0, 1fr) max-content minmax(0, 1fr)';
    row.style.gap = '4px 6px';
    row.style.alignItems = 'center';
    const sources = programRowCells(row);
    Array.prototype.forEach.call(row.children, function (el) {
      if (el.tagName === 'BUTTON' || sources.indexOf(el) !== -1) return;
      el.setAttribute('data-prg-hidden', '1');
      el.style.display = 'none';
    });
    Array.prototype.forEach.call(row.children, function (el) {
      if (el.tagName === 'LABEL' || el.style.marginLeft === '') return;
      el.setAttribute('data-prg-ml', el.style.marginLeft);
      el.style.setProperty('margin-left', '0', 'important');
    });
    sources.forEach(function (el, i) {
      if (el.tagName === 'INPUT' || el.tagName === 'SELECT') el.style.width = '100%';
      // Метка без подписи (например, «№») занимает пару «подпись + поле», иначе
      // все следующие элементы сдвигаются на одну колонку сетки.
      if (el.tagName === 'LABEL' || !labels[i]) { el.style.gridColumn = 'span 2'; return; }
      const tag = document.createElement('span');
      tag.className = 'prg-col-label';
      tag.textContent = labels[i];
      row.insertBefore(tag, el);
    });
  }

  function clearProgramRowMobile(row) {
    if (!row.hasAttribute('data-prg-mob')) return;
    row.removeAttribute('data-prg-mob');
    (row._prgText || []).forEach(function (t) { row.insertBefore(t[0], t[1]); });
    row._prgText = null;
    ['display', 'grid-template-columns', 'gap', 'align-items'].forEach(function (k) { row.style.removeProperty(k); });
    row.querySelectorAll('.prg-col-label').forEach(function (t) { t.remove(); });
    row.querySelectorAll('[data-prg-hidden]').forEach(function (el) {
      el.removeAttribute('data-prg-hidden');
      el.style.removeProperty('display');
    });
    Array.prototype.forEach.call(row.children, function (el) {
      if (el.tagName === 'INPUT' || el.tagName === 'SELECT') el.style.removeProperty('width');
      el.style.removeProperty('grid-column');
      if (el.hasAttribute('data-prg-ml')) {
        el.style.setProperty('margin-left', el.getAttribute('data-prg-ml'), 'important');
        el.removeAttribute('data-prg-ml');
      }
    });
  }

  function programRows(header) {
    return Array.prototype.filter.call(header.parentNode.querySelectorAll('.prgline'), function (el) {
      return !el.matches(PROGRAM_HEADER_SELECTOR);
    });
  }

  function alignProgramHeader(header) {
    const cells = [];
    Array.prototype.slice.call(header.childNodes).forEach(function (node) {
      if (node.nodeType !== 1) { header.removeChild(node); return; }
      if (node.tagName === 'SPAN' && node.textContent.trim() === '') { header.removeChild(node); return; }
      cells.push(node);
    });
    const rows = programRows(header);
    const row = rows[0];
    // Вкладка «Программа» закрыта - мерить нечего; довыравняем при её открытии (openTab).
    if (row && row.getClientRects().length === 0) return;

    // Режим - по факту: сначала снимаем телефонную раскладку и смотрим, уложились ли
    // поля первой строки в одну линию при обычных стилях.
    rows.forEach(clearProgramRowMobile);
    header.style.removeProperty('display');
    const sources = row ? programRowCells(row) : [];
    let wrapped = false;
    if (sources.length > 1) {
      // Сравниваем центры по вертикали: строчная подпись «№» и поле в одной линии
      // отличаются по top на несколько пикселей, перенос - на высоту поля.
      const rects = sources.map(function (el) { return el.getBoundingClientRect(); });
      const tallest = Math.max.apply(null, rects.map(function (r) { return r.height; }));
      const cy0 = rects[0].top + rects[0].height / 2;
      wrapped = rects.some(function (r) { return Math.abs(r.top + r.height / 2 - cy0) > tallest * 0.6; });
    }

    if (wrapped) {
      const labels = cells.map(programHeaderLabelText);
      header.style.display = 'none';
      rows.forEach(function (r) { applyProgramRowMobile(r, labels); });
      return;
    }
    if (!row) {
      ['flex-wrap', 'align-items'].forEach(function (k) { header.style.removeProperty(k); });
      cells.forEach(function (cell) { cell.removeAttribute('style'); });
      return;
    }
    const rowLeft = row.getBoundingClientRect().left;
    header.style.display = 'flex';
    header.style.flexWrap = 'nowrap';
    header.style.alignItems = 'center';
    let prevRight = 0;
    cells.forEach(function (cell, i) {
      const src = sources[i];
      if (!src) { cell.removeAttribute('style'); return; }
      const r = src.getBoundingClientRect();
      cell.style.setProperty('margin-left', (r.left - rowLeft - prevRight) + 'px', 'important');
      cell.style.setProperty('width', r.width + 'px', 'important');
      cell.style.flex = '0 0 auto';
      cell.style.boxSizing = 'border-box';
      cell.style.display = 'flex';
      cell.style.justifyContent = 'center';
      cell.style.textAlign = 'center';
      cell.style.whiteSpace = 'normal';
      cell.style.lineHeight = '1.1';
      prevRight = r.right - rowLeft;
    });
  }

  function alignProgramHeaders() {
    document.querySelectorAll(PROGRAM_HEADER_SELECTOR).forEach(alignProgramHeader);
  }

  let programHeaderAlignPending = false;
  function scheduleProgramHeaderAlign() {
    if (programHeaderAlignPending) return;
    programHeaderAlignPending = true;
    window.requestAnimationFrame(function () {
      programHeaderAlignPending = false;
      alignProgramHeaders();
    });
  }

  // typeof-проверка: smoke-тесты гоняют app.js в Node (vm) без DOM-наблюдателя.
  if (typeof MutationObserver !== 'undefined') {
    new MutationObserver(function (mutations) {
      for (let i = 0; i < mutations.length; i++) {
        const added = mutations[i].addedNodes;
        for (let j = 0; j < added.length; j++) {
          const node = added[j];
          if (node.nodeType === 1 && (node.classList.contains('prgline') || node.matches(PROGRAM_HEADER_SELECTOR))) {
            scheduleProgramHeaderAlign();
            return;
          }
        }
      }
    }).observe(document.documentElement, { childList: true, subtree: true });
    window.addEventListener('resize', scheduleProgramHeaderAlign);
    window.addEventListener('load', scheduleProgramHeaderAlign);
  }

  // Реальная высота шапки .top (ряд вкладок переносится на вторую строку, и
  // фиксированные 56px в --top-h не совпадают). Всплывающие блоки берут --top-real.
  function trackHeaderHeight() {
    const top = document.querySelector('.top');
    if (!top) return;
    function apply() {
      document.documentElement.style.setProperty('--top-real', Math.round(top.getBoundingClientRect().height) + 'px');
    }
    apply();
    if (typeof ResizeObserver !== 'undefined') new ResizeObserver(apply).observe(top);
    window.addEventListener('resize', apply);
  }

  // Подсветка текущего раздела в навигации второстепенных страниц (расчёт, график, настройки).
  function markCurrentNavLink() {
    const path = location.pathname.replace(/^\/+/, '');
    document.querySelectorAll('.page-nav .nav-link').forEach(function (link) {
      const href = (link.getAttribute('href') || '').replace(/^\/+/, '');
      if (href && href === path) link.setAttribute('aria-current', 'page');
    });
  }

  function applyModeNavigation(mode) {
    const targetByMode = {
      0: { href: '/program.htm', label: '计算' },
      2: { href: '/brewxml.htm', label: '配方' },
      7: { href: '/cheese-recipes.htm', label: '配方' }
    };
    const target = targetByMode[Number(mode)];
    document.querySelectorAll('[data-mode-navigation-slot]').forEach(function (link) {
      link.hidden = !target;
      link.removeAttribute('aria-current');
      if (!target) return;
      link.setAttribute('href', target.href);
      link.textContent = target.label;
      if (location.pathname === target.href) link.setAttribute('aria-current', 'page');
    });
    document.querySelectorAll('[data-rectification-navigation]').forEach(function (tab) {
      tab.hidden = Number(mode) !== 0;
    });
  }

  // На телефоне карточка «Действия» - фиксированная панель внизу, но лежит внутри
  // вкладки «Режим»: при переходе на «Программа» кнопка выключения нагрева пропадала.
  // Выносим панель из вкладки на узком экране и возвращаем на место на широком.
  function relocateActionsPanel() {
    if (typeof matchMedia !== 'function') return;
    const panel = document.querySelector('.sec-actions');
    const form = panel && panel.closest('form');
    if (!panel || !form) return;
    const placeholder = document.createComment('sec-actions');
    const mq = matchMedia('(max-width: 640px)');
    function apply() {
      if (mq.matches && panel.parentNode !== form) {
        panel.parentNode.insertBefore(placeholder, panel);
        form.appendChild(panel);
      } else if (!mq.matches && placeholder.parentNode) {
        placeholder.parentNode.insertBefore(panel, placeholder);
        placeholder.parentNode.removeChild(placeholder);
      }
    }
    apply();
    if (typeof mq.addEventListener === 'function') mq.addEventListener('change', apply);
  }

  // Несохранённые правки таблицы программы: вкладки «График», «Настройки», «Расчёт»
  // в шапке ведут на другие страницы, и правки терялись молча. Ссылки спрашивают
  // confirmLeave() - как confirmLeaveIfDirty() в setup.htm.
  let programDirty = false;
  let programRevision = 0;
  function markProgramDirty() {
    programDirty = true;
    programRevision += 1;
  }

  function trackProgramDirty() {
    const prog = byId('Prog');
    if (!prog) return;
    prog.addEventListener('input', markProgramDirty);
    prog.addEventListener('change', markProgramDirty);
  }

  function markProgramSaved(revision) {
    if (revision === undefined || revision === programRevision) programDirty = false;
  }

  function confirmLeave() {
    return !programDirty || confirm('程序已更改但未安装。不保存就离开?');
  }

  function setupPageChrome() {
    trackHeaderHeight();
    markCurrentNavLink();
    relocateActionsPanel();
    trackProgramDirty();
  }

  // Тесты грузят app.js в Node без DOM и location - тогда оформление страницы не нужно.
  if (typeof window !== 'undefined' && typeof location !== 'undefined' &&
      typeof document.querySelector === 'function') {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', setupPageChrome);
    else setupPageChrome();
  }

  function init(options) {
    const initOptions = options || {};
    initConnection(initOptions);
    initTheme({
      dynamicThemeTitle: initOptions.dynamicThemeTitle === true,
      implicitSystemTheme: initOptions.implicitSystemTheme === true
    });
    document.addEventListener('click', unlockAudio, { once: true });
    document.addEventListener('keydown', unlockAudio, { once: true });
  }

  window.SamovarApp = {
    addLuaButtons: addLuaButtons,
    addMessage: addMessage,
    beerRowTypeOk: beerRowTypeOk,
    beerScheduledDeviceValid: beerScheduledDeviceValid,
    beerBrewOrders: beerBrewOrders,
    beerBrewOrder: beerBrewOrder,
    beerProgramMaxRows: BEER_PROGRAM_MAX_ROWS,
    beerProgramRow: beerProgramRow,
    beerSensorOptionHtml: beerSensorOptionHtml,
    normalizeMashStepType: normalizeMashStepType,
    effectiveMashKind: effectiveMashKind,
    applyBeerBrewOrderToProgramText: applyBeerBrewOrderToProgramText,
    buildBeerMashStageLines: buildBeerMashStageLines,
    setConfiguredBeerBrewOrder: setConfiguredBeerBrewOrder,
    currentBeerBrewOrderId: currentBeerBrewOrderId,
    clearProgram: clearProgram,
    clearHistory: clearHistory,
    clearMessages: clearMessages,
    closeDeviceScheduleModal: closeDeviceScheduleModal,
    clearRequestError: clearRequestError,
    clearRequestErrorIfUnchanged: clearRequestErrorIfUnchanged,
    cssVar: cssVar,
    detectorIdleText: detectorIdleText,
    currentRequestErrorRevision: currentRequestErrorRevision,
    descriptionByteLength: descriptionByteLength,
    deviceScheduleMaxSeconds: 65535,
    alignProgramHeaders: alignProgramHeaders,
    enhanceTooltips: enhanceTooltips,
    escapeHtml: escapeHtml,
    fetchJson: fetchJson,
    fieldLabelFromDom: fieldLabelFromDom,
    init: init,
    initTheme: initTheme,
    loadUiBootstrap: loadUiBootstrap,
    notify: notify,
    normalizeDeviceScheduleSeconds: normalizeDeviceScheduleSeconds,
    openDeviceScheduleModal: openDeviceScheduleModal,
    addLuaProgramArgument: addLuaProgramArgument,
    closeLuaProgramModal: closeLuaProgramModal,
    openLuaProgramModal: openLuaProgramModal,
    openTab: openTab,
    onRuntimePair: onRuntimePair,
    onTelemetry: onTelemetry,
    pollAjax: pollAjax,
    renderScheme: renderScheme,
    postProgram: postProgram,
    readOperationAcceptance: readOperationAcceptance,
    renderI2cPumpStatus: renderI2cPumpStatus,
    renderUiDetails: renderUiDetails,
    uiWaitReasonName: uiWaitReasonName,
    renderTelemetryCommon: renderTelemetryCommon,
    removeLastMessage: removeLastMessage,
    removeMessage: removeMessage,
    markProgramSaved: markProgramSaved,
    markProgramDirty: markProgramDirty,
    confirmLeave: confirmLeave,
    applyModeNavigation: applyModeNavigation,
    applySensorColor: applySensorColor,
    reportUiError: reportUiError,
    readNumericInput: readNumericInput,
    responseErrorText: responseErrorText,
    runLua: runLua,
    runLuaString: runLuaString,
    sendCommand: sendCommand,
    sendI2cPump: sendI2cPump,
    sendNumericCommand: sendNumericCommand,
    sendPowerCommand: sendPowerCommand,
    saveDeviceScheduleModal: saveDeviceScheduleModal,
    saveLuaProgramModal: saveLuaProgramModal,
    setConnectionError: setConnectionError,
    setConnectionOk: setConnectionOk,
    setSoundEnabled: setSoundEnabled,
    showHistory: showHistory,
    showRequestError: showRequestError,
    startPollLoop: startPollLoop,
    startTelemetryPage: startTelemetryPage,
    stopI2cPump: stopI2cPump,
    toggleTheme: toggleTheme,
    validateNumericFields: validateNumericFields,
    validateNumericInput: validateNumericInput,
    waitForOperation: waitForOperation
  };
})();
